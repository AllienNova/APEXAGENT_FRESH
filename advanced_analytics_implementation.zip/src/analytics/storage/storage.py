"""
Storage module for the Advanced Analytics system.

This module provides components for storing and retrieving analytics data,
including time series metrics, events, and aggregated statistics.
"""

import json
import logging
import os
import sqlite3
import threading
import time
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple, Union

from ..core.core import (AnalyticsComponent, AnalyticsContext, DataCategory,
                        Event, MetricRegistry, MetricType, MetricValue,
                        SecurityClassification, metric_registry)

# Configure logging
logger = logging.getLogger(__name__)

# Global storage instance for module-level functions
_global_storage_instance: Optional['AnalyticsStorage'] = None

def initialize_storage(config: Dict[str, Any] = None) -> 'AnalyticsStorage':
    """
    Initialize the global storage instance.
    
    Args:
        config: Configuration dictionary for the storage
        
    Returns:
        Initialized storage instance
    """
    global _global_storage_instance
    
    if _global_storage_instance is None:
        _global_storage_instance = AnalyticsStorage("global_analytics_storage")
        _global_storage_instance.initialize(config or {})
        logger.info("Initialized global storage instance")
    
    return _global_storage_instance

def get_storage() -> 'AnalyticsStorage':
    """
    Get the global storage instance.
    
    Returns:
        Global storage instance
        
    Raises:
        RuntimeError: If global storage is not initialized
    """
    if _global_storage_instance is None:
        raise RuntimeError("Global storage instance is not initialized")
    
    return _global_storage_instance

def query_metrics(metric_name: str, start_time: datetime, end_time: datetime,
                 dimensions: Optional[Dict[str, str]] = None,
                 aggregation: Optional[str] = None,
                 interval: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Query metrics within a time range.
    
    Args:
        metric_name: Name of the metric
        start_time: Start time for the query
        end_time: End time for the query
        dimensions: Optional dimensions to filter by
        aggregation: Optional aggregation function (avg, sum, min, max, count)
        interval: Optional time interval for aggregation (e.g., "1h", "1d")
        
    Returns:
        List of metric values matching the query
    """
    storage = get_storage()
    metrics_storage = storage.get_metrics_storage()
    return metrics_storage.query_metrics(
        metric_name, start_time, end_time, dimensions, aggregation, interval
    )

def query_events(event_type: Optional[str] = None,
                start_time: Optional[datetime] = None,
                end_time: Optional[datetime] = None,
                source: Optional[str] = None,
                filters: Optional[Dict[str, Any]] = None,
                limit: int = 100) -> List[Dict[str, Any]]:
    """
    Query events within a time range.
    
    Args:
        event_type: Optional type of events to filter by
        start_time: Optional start time for the query
        end_time: Optional end time for the query
        source: Optional source to filter by
        filters: Optional filters for event data
        limit: Maximum number of events to return
        
    Returns:
        List of events matching the query
    """
    storage = get_storage()
    event_storage = storage.get_event_storage()
    return event_storage.query_events(
        event_type, start_time, end_time, source, filters, limit
    )

class StorageProvider(AnalyticsComponent, ABC):
    """Base class for all storage providers."""
    
    def __init__(self, name: str):
        super().__init__(name)
        self.enabled = False
        self.config: Dict[str, Any] = {}
        self._logger = logging.getLogger(f"{__name__}.{name}")
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize the storage provider with the provided configuration."""
        self.config = config
        self.enabled = config.get("enabled", True)
        self._logger.info(f"Initialized storage provider: {self.name}")
    
    def shutdown(self) -> None:
        """Shutdown the storage provider and release resources."""
        self.enabled = False
        self._logger.info(f"Shutdown storage provider: {self.name}")
    
    def get_health(self) -> Dict[str, Any]:
        """Get the health status of the storage provider."""
        return {
            "name": self.name,
            "enabled": self.enabled,
            "status": "healthy" if self.enabled else "disabled"
        }
    
    @abstractmethod
    def store_metric(self, metric: MetricValue) -> bool:
        """Store a metric value."""
        pass
    
    @abstractmethod
    def store_event(self, event: Event) -> bool:
        """Store an event."""
        pass
    
    @abstractmethod
    def query_metrics(self, metric_name: str, start_time: datetime, end_time: datetime,
                     dimensions: Dict[str, str] = None, aggregation: str = None,
                     interval: str = None) -> List[Dict[str, Any]]:
        """Query metrics within a time range."""
        pass
    
    @abstractmethod
    def query_events(self, event_type: str = None, start_time: datetime = None,
                    end_time: datetime = None, source: str = None,
                    filters: Dict[str, Any] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """Query events within a time range."""
        pass

class SQLiteStorageProvider(StorageProvider):
    """Storage provider using SQLite database."""
    
    def __init__(self, name: str = "sqlite_storage_provider"):
        super().__init__(name)
        self._db_path = None
        self._connection = None
        self._lock = threading.RLock()
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize the SQLite storage provider."""
        super().initialize(config)
        
        # Get database path from config
        self._db_path = config.get("db_path", "analytics.db")
        
        # Create database directory if it doesn't exist
        os.makedirs(os.path.dirname(os.path.abspath(self._db_path)), exist_ok=True)
        
        # Initialize database
        self._initialize_database()
        
        self._logger.info(f"Initialized SQLite storage provider with database: {self._db_path}")
    
    def shutdown(self) -> None:
        """Shutdown the SQLite storage provider."""
        with self._lock:
            if self._connection is not None:
                self._connection.close()
                self._connection = None
        
        super().shutdown()
    
    def _get_connection(self) -> sqlite3.Connection:
        """Get a database connection."""
        with self._lock:
            if self._connection is None:
                self._connection = sqlite3.connect(self._db_path, check_same_thread=False)
                self._connection.row_factory = sqlite3.Row
            
            return self._connection
    
    def _initialize_database(self) -> None:
        """Initialize the database schema."""
        conn = self._get_connection()
        
        with self._lock:
            cursor = conn.cursor()
            
            # Create metrics table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                metric_name TEXT NOT NULL,
                value REAL NOT NULL,
                timestamp DATETIME NOT NULL,
                dimensions TEXT
            )
            ''')
            
            # Create events table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id TEXT NOT NULL,
                event_type TEXT NOT NULL,
                timestamp DATETIME NOT NULL,
                source TEXT NOT NULL,
                data TEXT NOT NULL,
                correlation_id TEXT,
                category TEXT,
                security_classification TEXT
            )
            ''')
            
            # Create indexes
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_metrics_name_time ON metrics (metric_name, timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_metrics_timestamp ON metrics (timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_events_type_time ON events (event_type, timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events (timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_events_source ON events (source)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_events_correlation ON events (correlation_id)')
            
            conn.commit()
    
    def store_metric(self, metric: MetricValue) -> bool:
        """Store a metric value in the database."""
        if not self.enabled:
            return False
        
        try:
            conn = self._get_connection()
            
            with self._lock:
                cursor = conn.cursor()
                
                # Convert dimensions to JSON string
                dimensions_json = json.dumps(metric.dimensions) if metric.dimensions else None
                
                # Insert metric
                cursor.execute(
                    'INSERT INTO metrics (metric_name, value, timestamp, dimensions) VALUES (?, ?, ?, ?)',
                    (metric.metric_name, float(metric.value), metric.timestamp.isoformat(), dimensions_json)
                )
                
                conn.commit()
                
                return True
        
        except Exception as e:
            self._logger.error(f"Error storing metric: {e}")
            return False
    
    def store_event(self, event: Event) -> bool:
        """Store an event in the database."""
        if not self.enabled:
            return False
        
        try:
            conn = self._get_connection()
            
            with self._lock:
                cursor = conn.cursor()
                
                # Convert data to JSON string
                data_json = json.dumps(event.data)
                
                # Convert category and security classification to strings
                category_str = event.category.value if event.category else None
                security_str = event.security_classification.value if event.security_classification else None
                
                # Insert event
                cursor.execute(
                    '''INSERT INTO events 
                       (event_id, event_type, timestamp, source, data, correlation_id, category, security_classification) 
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                    (event.event_id, event.event_type, event.timestamp.isoformat(), event.source,
                     data_json, event.correlation_id, category_str, security_str)
                )
                
                conn.commit()
                
                return True
        
        except Exception as e:
            self._logger.error(f"Error storing event: {e}")
            return False
    
    def query_metrics(self, metric_name: str, start_time: datetime, end_time: datetime,
                     dimensions: Dict[str, str] = None, aggregation: str = None,
                     interval: str = None) -> List[Dict[str, Any]]:
        """Query metrics within a time range."""
        if not self.enabled:
            return []
        
        try:
            conn = self._get_connection()
            
            with self._lock:
                cursor = conn.cursor()
                
                # Base query
                query = 'SELECT * FROM metrics WHERE metric_name = ? AND timestamp >= ? AND timestamp <= ?'
                params = [metric_name, start_time.isoformat(), end_time.isoformat()]
                
                # Add dimensions filter if provided
                if dimensions:
                    # This is a simple implementation that checks if the JSON string contains all key-value pairs
                    # A more robust implementation would use JSON functions if available in SQLite
                    for key, value in dimensions.items():
                        query += f" AND dimensions LIKE ?"
                        params.append(f'%"{key}": "{value}"%')
                
                # Add order by
                query += ' ORDER BY timestamp ASC'
                
                # Execute query
                cursor.execute(query, params)
                
                # Fetch results
                rows = cursor.fetchall()
                
                # Convert to list of dictionaries
                results = []
                for row in rows:
                    dimensions_dict = json.loads(row['dimensions']) if row['dimensions'] else {}
                    
                    results.append({
                        'metric_name': row['metric_name'],
                        'value': row['value'],
                        'timestamp': datetime.fromisoformat(row['timestamp']),
                        'dimensions': dimensions_dict
                    })
                
                # Apply aggregation if requested
                if aggregation and results:
                    if interval:
                        # Group by time interval and apply aggregation
                        interval_seconds = self._parse_interval(interval)
                        grouped_results = self._group_by_interval(results, interval_seconds)
                        
                        aggregated_results = []
                        for timestamp, group in grouped_results.items():
                            values = [item['value'] for item in group]
                            
                            if aggregation == 'avg':
                                agg_value = sum(values) / len(values)
                            elif aggregation == 'sum':
                                agg_value = sum(values)
                            elif aggregation == 'min':
                                agg_value = min(values)
                            elif aggregation == 'max':
                                agg_value = max(values)
                            elif aggregation == 'count':
                                agg_value = len(values)
                            else:
                                agg_value = sum(values) / len(values)  # Default to avg
                            
                            aggregated_results.append({
                                'metric_name': metric_name,
                                'value': agg_value,
                                'timestamp': timestamp,
                                'dimensions': dimensions or {}
                            })
                        
                        return sorted(aggregated_results, key=lambda x: x['timestamp'])
                    else:
                        # Apply aggregation to all results
                        values = [item['value'] for item in results]
                        
                        if aggregation == 'avg':
                            agg_value = sum(values) / len(values)
                        elif aggregation == 'sum':
                            agg_value = sum(values)
                        elif aggregation == 'min':
                            agg_value = min(values)
                        elif aggregation == 'max':
                            agg_value = max(values)
                        elif aggregation == 'count':
                            agg_value = len(values)
                        else:
                            agg_value = sum(values) / len(values)  # Default to avg
                        
                        return [{
                            'metric_name': metric_name,
                            'value': agg_value,
                            'timestamp': start_time,
                            'dimensions': dimensions or {}
                        }]
                
                return results
        
        except Exception as e:
            self._logger.error(f"Error querying metrics: {e}")
            return []
    
    def query_events(self, event_type: str = None, start_time: datetime = None,
                    end_time: datetime = None, source: str = None,
                    filters: Dict[str, Any] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """Query events within a time range."""
        if not self.enabled:
            return []
        
        try:
            conn = self._get_connection()
            
            with self._lock:
                cursor = conn.cursor()
                
                # Base query
                query = 'SELECT * FROM events WHERE 1=1'
                params = []
                
                # Add filters
                if event_type:
                    query += ' AND event_type = ?'
                    params.append(event_type)
                
                if start_time:
                    query += ' AND timestamp >= ?'
                    params.append(start_time.isoformat())
                
                if end_time:
                    query += ' AND timestamp <= ?'
                    params.append(end_time.isoformat())
                
                if source:
                    query += ' AND source = ?'
                    params.append(source)
                
                # Add order by and limit
                query += ' ORDER BY timestamp DESC LIMIT ?'
                params.append(limit)
                
                # Execute query
                cursor.execute(query, params)
                
                # Fetch results
                rows = cursor.fetchall()
                
                # Convert to list of dictionaries
                results = []
                for row in rows:
                    data_dict = json.loads(row['data'])
                    
                    # Apply additional filters if provided
                    if filters:
                        match = True
                        for key, value in filters.items():
                            if key not in data_dict or data_dict[key] != value:
                                match = False
                                break
                        
                        if not match:
                            continue
                    
                    results.append({
                        'event_id': row['event_id'],
                        'event_type': row['event_type'],
                        'timestamp': datetime.fromisoformat(row['timestamp']),
                        'source': row['source'],
                        'data': data_dict,
                        'correlation_id': row['correlation_id'],
                        'category': row['category'],
                        'security_classification': row['security_classification']
                    })
                
                return results
        
        except Exception as e:
            self._logger.error(f"Error querying events: {e}")
            return []
    
    def _parse_interval(self, interval: str) -> int:
        """Parse an interval string to seconds."""
        if not interval:
            return 3600  # Default to 1 hour
        
        try:
            if interval.endswith('s'):
                return int(interval[:-1])
            elif interval.endswith('m'):
                return int(interval[:-1]) * 60
            elif interval.endswith('h'):
                return int(interval[:-1]) * 3600
            elif interval.endswith('d'):
                return int(interval[:-1]) * 86400
            else:
                return int(interval)
        except ValueError:
            return 3600  # Default to 1 hour
    
    def _group_by_interval(self, metrics: List[Dict[str, Any]], interval_seconds: int) -> Dict[datetime, List[Dict[str, Any]]]:
        """Group metrics by time interval."""
        grouped = {}
        
        for metric in metrics:
            timestamp = metric['timestamp']
            # Round down to the nearest interval
            interval_timestamp = timestamp.replace(
                microsecond=0,
                second=timestamp.second - (timestamp.second % 60),
                minute=timestamp.minute - (timestamp.minute % (interval_seconds // 60 if interval_seconds >= 60 else 1))
            )
            
            if interval_seconds >= 3600:
                # Round down to the nearest hour
                interval_timestamp = interval_timestamp.replace(
                    minute=0,
                    second=0
                )
            
            if interval_seconds >= 86400:
                # Round down to the nearest day
                interval_timestamp = interval_timestamp.replace(
                    hour=0,
                    minute=0,
                    second=0
                )
            
            if interval_timestamp not in grouped:
                grouped[interval_timestamp] = []
            
            grouped[interval_timestamp].append(metric)
        
        return grouped

class MemoryStorageProvider(StorageProvider):
    """Storage provider using in-memory storage."""
    
    def __init__(self, name: str = "memory_storage_provider"):
        super().__init__(name)
        self._metrics = []
        self._events = []
        self._lock = threading.RLock()
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """Initialize the memory storage provider."""
        super().initialize(config)
        
        # Clear existing data
        with self._lock:
            self._metrics = []
            self._events = []
        
        self._logger.info("Initialized memory storage provider")
    
    def shutdown(self) -> None:
        """Shutdown the memory storage provider."""
        with self._lock:
            self._metrics = []
            self._events = []
        
        super().shutdown()
    
    def store_metric(self, metric: MetricValue) -> bool:
        """Store a metric value in memory."""
        if not self.enabled:
            return False
        
        try:
            with self._lock:
                self._metrics.append({
                    'metric_name': metric.metric_name,
                    'value': metric.value,
                    'timestamp': metric.timestamp,
                    'dimensions': metric.dimensions.copy() if metric.dimensions else {}
                })
            
            return True
        
        except Exception as e:
            self._logger.error(f"Error storing metric: {e}")
            return False
    
    def store_event(self, event: Event) -> bool:
        """Store an event in memory."""
        if not self.enabled:
            return False
        
        try:
            with self._lock:
                self._events.append({
                    'event_id': event.event_id,
                    'event_type': event.event_type,
                    'timestamp': event.timestamp,
                    'source': event.source,
                    'data': event.data.copy() if event.data else {},
                    'correlation_id': event.correlation_id,
                    'category': event.category,
                    'security_classification': event.security_classification
                })
            
            return True
        
        except Exception as e:
            self._logger.error(f"Error storing event: {e}")
            return False
    
    def query_metrics(self, metric_name: str, start_time: datetime, end_time: datetime,
                     dimensions: Dict[str, str] = None, aggregation: str = None,
                     interval: str = None) -> List[Dict[str, Any]]:
        """Query metrics within a time range."""
        if not self.enabled:
            return []
        
        try:
            with self._lock:
                # Convert timestamps to Unix timestamps for comparison
                start_ts = int(start_time.timestamp() * 1000)
                end_ts = int(end_time.timestamp() * 1000)
                
                # Filter metrics
                filtered_metrics = []
                for metric in self._metrics:
                    # Check metric name
                    if metric['metric_name'] != metric_name:
                        continue
                    
                    # Check timestamp
                    metric_ts = metric['timestamp']
                    if not (start_ts <= metric_ts <= end_ts):
                        continue
                    
                    # Check dimensions
                    if dimensions:
                        match = True
                        for key, value in dimensions.items():
                            if key not in metric['dimensions'] or metric['dimensions'][key] != value:
                                match = False
                                break
                        
                        if not match:
                            continue
                    
                    # Add to filtered metrics
                    filtered_metrics.append(metric.copy())
                
                # Apply aggregation if requested
                if aggregation and filtered_metrics:
                    if interval:
                        # Group by time interval and apply aggregation
                        interval_seconds = self._parse_interval(interval)
                        grouped_metrics = self._group_by_interval(filtered_metrics, interval_seconds)
                        
                        aggregated_metrics = []
                        for timestamp, group in grouped_metrics.items():
                            values = [item['value'] for item in group]
                            
                            if aggregation == 'avg':
                                agg_value = sum(values) / len(values)
                            elif aggregation == 'sum':
                                agg_value = sum(values)
                            elif aggregation == 'min':
                                agg_value = min(values)
                            elif aggregation == 'max':
                                agg_value = max(values)
                            elif aggregation == 'count':
                                agg_value = len(values)
                            else:
                                agg_value = sum(values) / len(values)  # Default to avg
                            
                            aggregated_metrics.append({
                                'metric_name': metric_name,
                                'value': agg_value,
                                'timestamp': datetime.fromtimestamp(timestamp / 1000),
                                'dimensions': dimensions or {}
                            })
                        
                        return sorted(aggregated_metrics, key=lambda x: x['timestamp'])
                    else:
                        # Apply aggregation to all metrics
                        values = [item['value'] for item in filtered_metrics]
                        
                        if aggregation == 'avg':
                            agg_value = sum(values) / len(values)
                        elif aggregation == 'sum':
                            agg_value = sum(values)
                        elif aggregation == 'min':
                            agg_value = min(values)
                        elif aggregation == 'max':
                            agg_value = max(values)
                        elif aggregation == 'count':
                            agg_value = len(values)
                        else:
                            agg_value = sum(values) / len(values)  # Default to avg
                        
                        return [{
                            'metric_name': metric_name,
                            'value': agg_value,
                            'timestamp': start_time,
                            'dimensions': dimensions or {}
                        }]
                
                # Convert timestamps to datetime objects
                for metric in filtered_metrics:
                    metric['timestamp'] = datetime.fromtimestamp(metric['timestamp'] / 1000)
                
                return sorted(filtered_metrics, key=lambda x: x['timestamp'])
        
        except Exception as e:
            self._logger.error(f"Error querying metrics: {e}")
            return []
    
    def query_events(self, event_type: str = None, start_time: datetime = None,
                    end_time: datetime = None, source: str = None,
                    filters: Dict[str, Any] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """Query events within a time range."""
        if not self.enabled:
            return []
        
        try:
            with self._lock:
                # Convert timestamps to Unix timestamps for comparison
                start_ts = int(start_time.timestamp() * 1000) if start_time else 0
                end_ts = int(end_time.timestamp() * 1000) if end_time else float('inf')
                
                # Filter events
                filtered_events = []
                for event in self._events:
                    # Check event type
                    if event_type and event['event_type'] != event_type:
                        continue
                    
                    # Check timestamp
                    event_ts = event['timestamp']
                    if not (start_ts <= event_ts <= end_ts):
                        continue
                    
                    # Check source
                    if source and event['source'] != source:
                        continue
                    
                    # Check additional filters
                    if filters:
                        match = True
                        for key, value in filters.items():
                            if key not in event['data'] or event['data'][key] != value:
                                match = False
                                break
                        
                        if not match:
                            continue
                    
                    # Add to filtered events
                    filtered_events.append(event.copy())
                
                # Sort by timestamp (newest first) and apply limit
                filtered_events.sort(key=lambda x: x['timestamp'], reverse=True)
                filtered_events = filtered_events[:limit]
                
                # Convert timestamps to datetime objects
                for event in filtered_events:
                    event['timestamp'] = datetime.fromtimestamp(event['timestamp'] / 1000)
                
                return filtered_events
        
        except Exception as e:
            self._logger.error(f"Error querying events: {e}")
            return []
    
    def _parse_interval(self, interval: str) -> int:
        """Parse an interval string to seconds."""
        if not interval:
            return 3600  # Default to 1 hour
        
        try:
            if interval.endswith('s'):
                return int(interval[:-1])
            elif interval.endswith('m'):
                return int(interval[:-1]) * 60
            elif interval.endswith('h'):
                return int(interval[:-1]) * 3600
            elif interval.endswith('d'):
                return int(interval[:-1]) * 86400
            else:
                return int(interval)
        except ValueError:
            return 3600  # Default to 1 hour
    
    def _group_by_interval(self, metrics: List[Dict[str, Any]], interval_seconds: int) -> Dict[int, List[Dict[str, Any]]]:
        """Group metrics by time interval."""
        grouped = {}
        
        for metric in metrics:
            timestamp = metric['timestamp']
            # Round down to the nearest interval
            interval_timestamp = timestamp - (timestamp % (interval_seconds * 1000))
            
            if interval_timestamp not in grouped:
                grouped[interval_timestamp] = []
            
            grouped[interval_timestamp].append(metric)
        
        return grouped

class AnalyticsStorage(AnalyticsComponent):
    """
    Storage component for analytics data.
    
    This class provides methods for storing and retrieving analytics data,
    including metrics, events, and aggregated statistics.
    """
    
    def __init__(self, name: str = "analytics_storage"):
        """
        Initialize the analytics storage component.
        
        Args:
            name: Name of the storage component
        """
        super().__init__(name)
        self._providers = {}
        self._default_provider = None
        self._metrics_storage = None
        self._event_storage = None
        self._time_series_storage = None
        self._logger = logging.getLogger(f"{__name__}.{name}")
        self._logger.info(f"Initialized AnalyticsStorage: {name}")
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """
        Initialize the analytics storage with the provided configuration.
        
        Args:
            config: Configuration dictionary for the storage
        """
        super().initialize(config)
        
        # Initialize storage providers
        providers_config = config.get("providers", {})
        
        # Initialize SQLite provider if configured
        if "sqlite" in providers_config:
            sqlite_provider = SQLiteStorageProvider("sqlite_provider")
            sqlite_provider.initialize(providers_config["sqlite"])
            self._providers["sqlite"] = sqlite_provider
        
        # Initialize memory provider if configured
        if "memory" in providers_config:
            memory_provider = MemoryStorageProvider("memory_provider")
            memory_provider.initialize(providers_config["memory"])
            self._providers["memory"] = memory_provider
        
        # Initialize memory provider as fallback if no providers configured
        if not self._providers:
            memory_provider = MemoryStorageProvider("memory_provider")
            memory_provider.initialize({})
            self._providers["memory"] = memory_provider
        
        # Set default provider
        default_provider_name = config.get("default_provider", "memory")
        if default_provider_name in self._providers:
            self._default_provider = self._providers[default_provider_name]
        else:
            # Use first available provider as default
            self._default_provider = next(iter(self._providers.values()))
        
        # Initialize storage components
        self._metrics_storage = MetricsStorage("metrics_storage", self._default_provider)
        self._event_storage = EventStorage("event_storage", self._default_provider)
        self._time_series_storage = TimeSeriesStorage("time_series_storage", self._default_provider)
        
        self._logger.info(f"Initialized AnalyticsStorage with {len(self._providers)} providers")
    
    def shutdown(self) -> None:
        """Shutdown the analytics storage and release resources."""
        # Shutdown storage components
        if self._metrics_storage:
            self._metrics_storage.shutdown()
        
        if self._event_storage:
            self._event_storage.shutdown()
        
        if self._time_series_storage:
            self._time_series_storage.shutdown()
        
        # Shutdown providers
        for provider in self._providers.values():
            provider.shutdown()
        
        self._providers = {}
        self._default_provider = None
        
        self._logger.info(f"Shutdown AnalyticsStorage: {self.name}")
        super().shutdown()
    
    def get_health(self) -> Dict[str, Any]:
        """
        Get the health status of the analytics storage.
        
        Returns:
            Dictionary containing health information
        """
        provider_health = {}
        for name, provider in self._providers.items():
            provider_health[name] = provider.get_health()
        
        return {
            "name": self.name,
            "enabled": self.enabled,
            "status": "healthy" if self.enabled else "disabled",
            "providers": provider_health,
            "default_provider": self._default_provider.name if self._default_provider else None
        }
    
    def get_provider(self, provider_name: str = None) -> StorageProvider:
        """
        Get a storage provider by name.
        
        Args:
            provider_name: Name of the provider to get (default: default provider)
            
        Returns:
            Storage provider
            
        Raises:
            ValueError: If provider not found
        """
        if provider_name is None:
            if self._default_provider is None:
                raise ValueError("No default provider configured")
            
            return self._default_provider
        
        if provider_name not in self._providers:
            raise ValueError(f"Provider not found: {provider_name}")
        
        return self._providers[provider_name]
    
    def get_metrics_storage(self) -> 'MetricsStorage':
        """
        Get the metrics storage component.
        
        Returns:
            Metrics storage component
        """
        return self._metrics_storage
    
    def get_event_storage(self) -> 'EventStorage':
        """
        Get the event storage component.
        
        Returns:
            Event storage component
        """
        return self._event_storage
    
    def get_time_series_storage(self) -> 'TimeSeriesStorage':
        """
        Get the time series storage component.
        
        Returns:
            Time series storage component
        """
        return self._time_series_storage
    
    def store_metric(self, metric_name: str, value: Union[int, float, bool],
                    dimensions: Dict[str, str] = None,
                    timestamp: Optional[datetime] = None,
                    provider_name: str = None) -> bool:
        """
        Store a metric value.
        
        Args:
            metric_name: Name of the metric
            value: Value of the metric
            dimensions: Dimensions for the metric
            timestamp: Timestamp for the metric (default: current time)
            provider_name: Name of the provider to use (default: default provider)
            
        Returns:
            True if storage succeeded, False otherwise
        """
        if not self.enabled:
            self._logger.debug(f"AnalyticsStorage is disabled, skipping store_metric: {metric_name}")
            return False
        
        try:
            # Use current time if timestamp not provided
            if timestamp is None:
                timestamp = datetime.now()
            
            # Convert boolean values to integers
            if isinstance(value, bool):
                value = 1 if value else 0
            
            # Create metric value
            metric = MetricValue(
                name=metric_name,
                value=value,
                dimensions=dimensions or {},
                timestamp=int(timestamp.timestamp() * 1000)
            )
            
            # Get provider
            provider = self.get_provider(provider_name)
            
            # Store metric
            return provider.store_metric(metric)
        
        except Exception as e:
            self._logger.error(f"Error storing metric: {e}")
            return False
    
    def store_event(self, event_type: str, event_data: Dict[str, Any],
                   source: str = "analytics",
                   correlation_id: str = None,
                   timestamp: Optional[datetime] = None,
                   provider_name: str = None) -> Optional[str]:
        """
        Store an event.
        
        Args:
            event_type: Type of the event
            event_data: Data associated with the event
            source: Source of the event
            correlation_id: Correlation ID for the event
            timestamp: Timestamp for the event (default: current time)
            provider_name: Name of the provider to use (default: default provider)
            
        Returns:
            Event ID if storage succeeded, None otherwise
        """
        if not self.enabled:
            self._logger.debug(f"AnalyticsStorage is disabled, skipping store_event: {event_type}")
            return None
        
        try:
            # Use current time if timestamp not provided
            if timestamp is None:
                timestamp = datetime.now()
            
            # Create event
            event = Event(
                event_type=event_type,
                data=event_data,
                source=source,
                correlation_id=correlation_id,
                timestamp=int(timestamp.timestamp() * 1000)
            )
            
            # Get provider
            provider = self.get_provider(provider_name)
            
            # Store event
            if provider.store_event(event):
                return event.event_id
            else:
                return None
        
        except Exception as e:
            self._logger.error(f"Error storing event: {e}")
            return None
    
    def query_metrics(self, metric_name: str, start_time: datetime, end_time: datetime,
                     dimensions: Dict[str, str] = None, aggregation: str = None,
                     interval: str = None, provider_name: str = None) -> List[Dict[str, Any]]:
        """
        Query metrics within a time range.
        
        Args:
            metric_name: Name of the metric
            start_time: Start time for the query
            end_time: End time for the query
            dimensions: Optional dimensions to filter by
            aggregation: Optional aggregation function (avg, sum, min, max, count)
            interval: Optional time interval for aggregation (e.g., "1h", "1d")
            provider_name: Name of the provider to use (default: default provider)
            
        Returns:
            List of metric values matching the query
        """
        if not self.enabled:
            self._logger.debug(f"AnalyticsStorage is disabled, returning empty list for query_metrics")
            return []
        
        try:
            # Get provider
            provider = self.get_provider(provider_name)
            
            # Query metrics
            return provider.query_metrics(
                metric_name, start_time, end_time, dimensions, aggregation, interval
            )
        
        except Exception as e:
            self._logger.error(f"Error querying metrics: {e}")
            return []
    
    def query_events(self, event_type: str = None, start_time: datetime = None,
                    end_time: datetime = None, source: str = None,
                    filters: Dict[str, Any] = None, limit: int = 100,
                    provider_name: str = None) -> List[Dict[str, Any]]:
        """
        Query events within a time range.
        
        Args:
            event_type: Optional type of events to filter by
            start_time: Optional start time for the query
            end_time: Optional end time for the query
            source: Optional source to filter by
            filters: Optional filters for event data
            limit: Maximum number of events to return
            provider_name: Name of the provider to use (default: default provider)
            
        Returns:
            List of events matching the query
        """
        if not self.enabled:
            self._logger.debug(f"AnalyticsStorage is disabled, returning empty list for query_events")
            return []
        
        try:
            # Get provider
            provider = self.get_provider(provider_name)
            
            # Query events
            return provider.query_events(
                event_type, start_time, end_time, source, filters, limit
            )
        
        except Exception as e:
            self._logger.error(f"Error querying events: {e}")
            return []

class MetricsStorage:
    """
    Storage component for metrics data.
    
    This class provides methods for storing and retrieving metrics data.
    """
    
    def __init__(self, name: str, provider: StorageProvider):
        """
        Initialize the metrics storage component.
        
        Args:
            name: Name of the storage component
            provider: Storage provider to use
        """
        self.name = name
        self.provider = provider
        self.enabled = True
        self._logger = logging.getLogger(f"{__name__}.{name}")
        self._logger.info(f"Initialized MetricsStorage: {name}")
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """
        Initialize the metrics storage with the provided configuration.
        
        Args:
            config: Configuration dictionary for the storage
        """
        self.enabled = config.get("enabled", True)
        self._logger.info(f"Initialized MetricsStorage: {self.name}")
    
    def shutdown(self) -> None:
        """Shutdown the metrics storage and release resources."""
        self.enabled = False
        self._logger.info(f"Shutdown MetricsStorage: {self.name}")
    
    def store_metric(self, metric: MetricValue) -> bool:
        """
        Store a metric value.
        
        Args:
            metric: Metric value to store
            
        Returns:
            True if storage succeeded, False otherwise
        """
        if not self.enabled:
            self._logger.debug(f"MetricsStorage is disabled, skipping store_metric: {metric.metric_name}")
            return False
        
        return self.provider.store_metric(metric)
    
    def query_metrics(self, metric_name: str, start_time: datetime, end_time: datetime,
                     dimensions: Dict[str, str] = None, aggregation: str = None,
                     interval: str = None) -> List[Dict[str, Any]]:
        """
        Query metrics within a time range.
        
        Args:
            metric_name: Name of the metric
            start_time: Start time for the query
            end_time: End time for the query
            dimensions: Optional dimensions to filter by
            aggregation: Optional aggregation function (avg, sum, min, max, count)
            interval: Optional time interval for aggregation (e.g., "1h", "1d")
            
        Returns:
            List of metric values matching the query
        """
        if not self.enabled:
            self._logger.debug(f"MetricsStorage is disabled, returning empty list for query_metrics")
            return []
        
        return self.provider.query_metrics(
            metric_name, start_time, end_time, dimensions, aggregation, interval
        )
    
    def get_metric_statistics(self, metric_name: str, start_time: datetime, end_time: datetime,
                            dimensions: Dict[str, str] = None) -> Dict[str, Any]:
        """
        Get statistics for a metric.
        
        Args:
            metric_name: Name of the metric
            start_time: Start time for the query
            end_time: End time for the query
            dimensions: Optional dimensions to filter by
            
        Returns:
            Dictionary containing metric statistics
        """
        if not self.enabled:
            self._logger.debug(f"MetricsStorage is disabled, returning empty dict for get_metric_statistics")
            return {}
        
        # Query metrics
        metrics = self.query_metrics(
            metric_name, start_time, end_time, dimensions
        )
        
        if not metrics:
            return {
                "metric_name": metric_name,
                "dimensions": dimensions or {},
                "count": 0,
                "min": None,
                "max": None,
                "avg": None,
                "sum": None,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat()
            }
        
        # Extract values
        values = [m["value"] for m in metrics]
        
        # Calculate statistics
        count = len(values)
        min_val = min(values)
        max_val = max(values)
        avg_val = sum(values) / count
        sum_val = sum(values)
        
        return {
            "metric_name": metric_name,
            "dimensions": dimensions or {},
            "count": count,
            "min": min_val,
            "max": max_val,
            "avg": avg_val,
            "sum": sum_val,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat()
        }

class EventStorage:
    """
    Storage component for event data.
    
    This class provides methods for storing and retrieving event data.
    """
    
    def __init__(self, name: str, provider: StorageProvider):
        """
        Initialize the event storage component.
        
        Args:
            name: Name of the storage component
            provider: Storage provider to use
        """
        self.name = name
        self.provider = provider
        self.enabled = True
        self._logger = logging.getLogger(f"{__name__}.{name}")
        self._logger.info(f"Initialized EventStorage: {name}")
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """
        Initialize the event storage with the provided configuration.
        
        Args:
            config: Configuration dictionary for the storage
        """
        self.enabled = config.get("enabled", True)
        self._logger.info(f"Initialized EventStorage: {self.name}")
    
    def shutdown(self) -> None:
        """Shutdown the event storage and release resources."""
        self.enabled = False
        self._logger.info(f"Shutdown EventStorage: {self.name}")
    
    def store_event(self, event: Event) -> bool:
        """
        Store an event.
        
        Args:
            event: Event to store
            
        Returns:
            True if storage succeeded, False otherwise
        """
        if not self.enabled:
            self._logger.debug(f"EventStorage is disabled, skipping store_event: {event.event_type}")
            return False
        
        return self.provider.store_event(event)
    
    def query_events(self, event_type: str = None, start_time: datetime = None,
                    end_time: datetime = None, source: str = None,
                    filters: Dict[str, Any] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Query events within a time range.
        
        Args:
            event_type: Optional type of events to filter by
            start_time: Optional start time for the query
            end_time: Optional end time for the query
            source: Optional source to filter by
            filters: Optional filters for event data
            limit: Maximum number of events to return
            
        Returns:
            List of events matching the query
        """
        if not self.enabled:
            self._logger.debug(f"EventStorage is disabled, returning empty list for query_events")
            return []
        
        return self.provider.query_events(
            event_type, start_time, end_time, source, filters, limit
        )
    
    def get_event_counts(self, event_types: List[str] = None,
                       start_time: datetime = None,
                       end_time: datetime = None,
                       group_by: str = None) -> Dict[str, int]:
        """
        Get counts of events by type or other grouping.
        
        Args:
            event_types: Optional list of event types to filter
            start_time: Optional start time to filter events
            end_time: Optional end time to filter events
            group_by: Optional field to group counts by (default: event_type)
            
        Returns:
            Dictionary of event counts
        """
        if not self.enabled:
            self._logger.debug(f"EventStorage is disabled, returning empty dict for get_event_counts")
            return {}
        
        # Query events
        events = self.query_events(
            event_type=event_types[0] if event_types and len(event_types) == 1 else None,
            start_time=start_time,
            end_time=end_time,
            limit=10000  # Use a high limit to get accurate counts
        )
        
        # Filter by event types if multiple types provided
        if event_types and len(event_types) > 1:
            events = [e for e in events if e["event_type"] in event_types]
        
        # Group by specified field or event_type by default
        group_field = group_by or "event_type"
        counts = {}
        
        for event in events:
            if group_field == "event_type":
                key = event["event_type"]
            elif group_field == "source":
                key = event["source"]
            elif group_field in event["data"]:
                key = str(event["data"][group_field])
            else:
                key = "unknown"
            
            if key not in counts:
                counts[key] = 0
            
            counts[key] += 1
        
        return counts

class TimeSeriesStorage:
    """
    Storage component for time series data.
    
    This class provides methods for storing and retrieving time series data.
    """
    
    def __init__(self, name: str, provider: StorageProvider):
        """
        Initialize the time series storage component.
        
        Args:
            name: Name of the storage component
            provider: Storage provider to use
        """
        self.name = name
        self.provider = provider
        self.enabled = True
        self._logger = logging.getLogger(f"{__name__}.{name}")
        self._logger.info(f"Initialized TimeSeriesStorage: {name}")
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """
        Initialize the time series storage with the provided configuration.
        
        Args:
            config: Configuration dictionary for the storage
        """
        self.enabled = config.get("enabled", True)
        self._logger.info(f"Initialized TimeSeriesStorage: {self.name}")
    
    def shutdown(self) -> None:
        """Shutdown the time series storage and release resources."""
        self.enabled = False
        self._logger.info(f"Shutdown TimeSeriesStorage: {self.name}")
    
    def store_time_series(self, series_name: str, value: Union[int, float],
                         dimensions: Dict[str, str] = None,
                         timestamp: Optional[datetime] = None) -> bool:
        """
        Store a time series data point.
        
        Args:
            series_name: Name of the time series
            value: Value of the data point
            dimensions: Dimensions for the data point
            timestamp: Timestamp for the data point (default: current time)
            
        Returns:
            True if storage succeeded, False otherwise
        """
        if not self.enabled:
            self._logger.debug(f"TimeSeriesStorage is disabled, skipping store_time_series: {series_name}")
            return False
        
        # Use current time if timestamp not provided
        if timestamp is None:
            timestamp = datetime.now()
        
        # Create metric value
        metric = MetricValue(
            name=series_name,
            value=value,
            dimensions=dimensions or {},
            timestamp=int(timestamp.timestamp() * 1000)
        )
        
        # Store metric
        return self.provider.store_metric(metric)
    
    def query_time_series(self, series_name: str, start_time: datetime, end_time: datetime,
                         dimensions: Dict[str, str] = None, aggregation: str = None,
                         interval: str = None) -> List[Dict[str, Any]]:
        """
        Query time series data within a time range.
        
        Args:
            series_name: Name of the time series
            start_time: Start time for the query
            end_time: End time for the query
            dimensions: Optional dimensions to filter by
            aggregation: Optional aggregation function (avg, sum, min, max, count)
            interval: Optional time interval for aggregation (e.g., "1h", "1d")
            
        Returns:
            List of time series data points matching the query
        """
        if not self.enabled:
            self._logger.debug(f"TimeSeriesStorage is disabled, returning empty list for query_time_series")
            return []
        
        return self.provider.query_metrics(
            series_name, start_time, end_time, dimensions, aggregation, interval
        )
    
    def get_time_series_statistics(self, series_name: str, start_time: datetime, end_time: datetime,
                                 dimensions: Dict[str, str] = None) -> Dict[str, Any]:
        """
        Get statistics for a time series.
        
        Args:
            series_name: Name of the time series
            start_time: Start time for the query
            end_time: End time for the query
            dimensions: Optional dimensions to filter by
            
        Returns:
            Dictionary containing time series statistics
        """
        if not self.enabled:
            self._logger.debug(f"TimeSeriesStorage is disabled, returning empty dict for get_time_series_statistics")
            return {}
        
        # Query time series data
        data_points = self.query_time_series(
            series_name, start_time, end_time, dimensions
        )
        
        if not data_points:
            return {
                "series_name": series_name,
                "dimensions": dimensions or {},
                "count": 0,
                "min": None,
                "max": None,
                "avg": None,
                "sum": None,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat()
            }
        
        # Extract values
        values = [p["value"] for p in data_points]
        
        # Calculate statistics
        count = len(values)
        min_val = min(values)
        max_val = max(values)
        avg_val = sum(values) / count
        sum_val = sum(values)
        
        return {
            "series_name": series_name,
            "dimensions": dimensions or {},
            "count": count,
            "min": min_val,
            "max": max_val,
            "avg": avg_val,
            "sum": sum_val,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat()
        }

class StorageManager(AnalyticsComponent):
    """
    Manager for analytics storage.
    
    This class provides a centralized interface for managing storage components
    and coordinating storage operations across the analytics system.
    """
    
    def __init__(self, name: str = "storage_manager"):
        """
        Initialize the storage manager.
        
        Args:
            name: Name of the storage manager component
        """
        super().__init__(name)
        self._storage = None
        self._retention_policies = {}
        self._cleanup_interval_seconds = 3600  # Default: 1 hour
        self._last_cleanup_time = 0
        self._logger = logging.getLogger(f"{__name__}.{name}")
        self._logger.info(f"Initialized StorageManager: {name}")
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """
        Initialize the storage manager with the provided configuration.
        
        Args:
            config: Configuration dictionary for the storage manager
        """
        super().initialize(config)
        
        # Initialize storage
        storage_config = config.get("storage", {})
        self._storage = AnalyticsStorage("managed_analytics_storage")
        self._storage.initialize(storage_config)
        
        # Set cleanup interval
        self._cleanup_interval_seconds = config.get("cleanup_interval_seconds", 3600)
        
        # Set retention policies
        retention_config = config.get("retention_policies", {})
        for data_type, policy in retention_config.items():
            self._retention_policies[data_type] = {
                "retention_days": policy.get("retention_days", 30),
                "aggregation_policy": policy.get("aggregation_policy", "none")
            }
        
        # Set default retention policies if not configured
        if "metrics" not in self._retention_policies:
            self._retention_policies["metrics"] = {
                "retention_days": 30,
                "aggregation_policy": "hourly"
            }
        
        if "events" not in self._retention_policies:
            self._retention_policies["events"] = {
                "retention_days": 90,
                "aggregation_policy": "none"
            }
        
        if "time_series" not in self._retention_policies:
            self._retention_policies["time_series"] = {
                "retention_days": 7,
                "aggregation_policy": "daily"
            }
        
        self._logger.info(f"Initialized StorageManager with {len(self._retention_policies)} retention policies")
    
    def shutdown(self) -> None:
        """Shutdown the storage manager and release resources."""
        if self._storage:
            self._storage.shutdown()
            self._storage = None
        
        self._retention_policies = {}
        
        self._logger.info(f"Shutdown StorageManager: {self.name}")
        super().shutdown()
    
    def get_health(self) -> Dict[str, Any]:
        """
        Get the health status of the storage manager.
        
        Returns:
            Dictionary containing health information
        """
        storage_health = self._storage.get_health() if self._storage else {"status": "not_initialized"}
        
        return {
            "name": self.name,
            "enabled": self.enabled,
            "status": "healthy" if self.enabled else "disabled",
            "storage": storage_health,
            "retention_policies": self._retention_policies,
            "last_cleanup_time": datetime.fromtimestamp(self._last_cleanup_time).isoformat() if self._last_cleanup_time > 0 else None
        }
    
    def get_storage(self) -> AnalyticsStorage:
        """
        Get the managed analytics storage.
        
        Returns:
            Analytics storage instance
            
        Raises:
            RuntimeError: If storage is not initialized
        """
        if self._storage is None:
            raise RuntimeError("Storage is not initialized")
        
        return self._storage
    
    def store_metric(self, metric_name: str, value: Union[int, float, bool],
                    dimensions: Dict[str, str] = None,
                    timestamp: Optional[datetime] = None,
                    provider_name: str = None) -> bool:
        """
        Store a metric value.
        
        Args:
            metric_name: Name of the metric
            value: Value of the metric
            dimensions: Dimensions for the metric
            timestamp: Timestamp for the metric (default: current time)
            provider_name: Name of the provider to use (default: default provider)
            
        Returns:
            True if storage succeeded, False otherwise
        """
        if not self.enabled:
            self._logger.debug(f"StorageManager is disabled, skipping store_metric: {metric_name}")
            return False
        
        # Check if cleanup is needed
        self._check_cleanup()
        
        # Store metric
        return self._storage.store_metric(metric_name, value, dimensions, timestamp, provider_name)
    
    def store_event(self, event_type: str, event_data: Dict[str, Any],
                   source: str = "analytics",
                   correlation_id: str = None,
                   timestamp: Optional[datetime] = None,
                   provider_name: str = None) -> Optional[str]:
        """
        Store an event.
        
        Args:
            event_type: Type of the event
            event_data: Data associated with the event
            source: Source of the event
            correlation_id: Correlation ID for the event
            timestamp: Timestamp for the event (default: current time)
            provider_name: Name of the provider to use (default: default provider)
            
        Returns:
            Event ID if storage succeeded, None otherwise
        """
        if not self.enabled:
            self._logger.debug(f"StorageManager is disabled, skipping store_event: {event_type}")
            return None
        
        # Check if cleanup is needed
        self._check_cleanup()
        
        # Store event
        return self._storage.store_event(event_type, event_data, source, correlation_id, timestamp, provider_name)
    
    def store_time_series(self, series_name: str, value: Union[int, float],
                         dimensions: Dict[str, str] = None,
                         timestamp: Optional[datetime] = None,
                         provider_name: str = None) -> bool:
        """
        Store a time series data point.
        
        Args:
            series_name: Name of the time series
            value: Value of the data point
            dimensions: Dimensions for the data point
            timestamp: Timestamp for the data point (default: current time)
            provider_name: Name of the provider to use (default: default provider)
            
        Returns:
            True if storage succeeded, False otherwise
        """
        if not self.enabled:
            self._logger.debug(f"StorageManager is disabled, skipping store_time_series: {series_name}")
            return False
        
        # Check if cleanup is needed
        self._check_cleanup()
        
        # Store time series data point
        time_series_storage = self._storage.get_time_series_storage()
        return time_series_storage.store_time_series(series_name, value, dimensions, timestamp)
    
    def query_metrics(self, metric_name: str, start_time: datetime, end_time: datetime,
                     dimensions: Dict[str, str] = None, aggregation: str = None,
                     interval: str = None, provider_name: str = None) -> List[Dict[str, Any]]:
        """
        Query metrics within a time range.
        
        Args:
            metric_name: Name of the metric
            start_time: Start time for the query
            end_time: End time for the query
            dimensions: Optional dimensions to filter by
            aggregation: Optional aggregation function (avg, sum, min, max, count)
            interval: Optional time interval for aggregation (e.g., "1h", "1d")
            provider_name: Name of the provider to use (default: default provider)
            
        Returns:
            List of metric values matching the query
        """
        if not self.enabled:
            self._logger.debug(f"StorageManager is disabled, returning empty list for query_metrics")
            return []
        
        return self._storage.query_metrics(
            metric_name, start_time, end_time, dimensions, aggregation, interval, provider_name
        )
    
    def query_events(self, event_type: str = None, start_time: datetime = None,
                    end_time: datetime = None, source: str = None,
                    filters: Dict[str, Any] = None, limit: int = 100,
                    provider_name: str = None) -> List[Dict[str, Any]]:
        """
        Query events within a time range.
        
        Args:
            event_type: Optional type of events to filter by
            start_time: Optional start time for the query
            end_time: Optional end time for the query
            source: Optional source to filter by
            filters: Optional filters for event data
            limit: Maximum number of events to return
            provider_name: Name of the provider to use (default: default provider)
            
        Returns:
            List of events matching the query
        """
        if not self.enabled:
            self._logger.debug(f"StorageManager is disabled, returning empty list for query_events")
            return []
        
        return self._storage.query_events(
            event_type, start_time, end_time, source, filters, limit, provider_name
        )
    
    def query_time_series(self, series_name: str, start_time: datetime, end_time: datetime,
                         dimensions: Dict[str, str] = None, aggregation: str = None,
                         interval: str = None, provider_name: str = None) -> List[Dict[str, Any]]:
        """
        Query time series data within a time range.
        
        Args:
            series_name: Name of the time series
            start_time: Start time for the query
            end_time: End time for the query
            dimensions: Optional dimensions to filter by
            aggregation: Optional aggregation function (avg, sum, min, max, count)
            interval: Optional time interval for aggregation (e.g., "1h", "1d")
            provider_name: Name of the provider to use (default: default provider)
            
        Returns:
            List of time series data points matching the query
        """
        if not self.enabled:
            self._logger.debug(f"StorageManager is disabled, returning empty list for query_time_series")
            return []
        
        time_series_storage = self._storage.get_time_series_storage()
        return time_series_storage.query_time_series(
            series_name, start_time, end_time, dimensions, aggregation, interval
        )
    
    def get_retention_policy(self, data_type: str) -> Dict[str, Any]:
        """
        Get the retention policy for a data type.
        
        Args:
            data_type: Type of data (metrics, events, time_series)
            
        Returns:
            Retention policy for the data type
        """
        return self._retention_policies.get(data_type, {
            "retention_days": 30,
            "aggregation_policy": "none"
        })
    
    def set_retention_policy(self, data_type: str, retention_days: int,
                           aggregation_policy: str = "none") -> None:
        """
        Set the retention policy for a data type.
        
        Args:
            data_type: Type of data (metrics, events, time_series)
            retention_days: Number of days to retain data
            aggregation_policy: Aggregation policy for older data (none, hourly, daily, monthly)
        """
        if not self.enabled:
            self._logger.debug(f"StorageManager is disabled, skipping set_retention_policy: {data_type}")
            return
        
        self._retention_policies[data_type] = {
            "retention_days": retention_days,
            "aggregation_policy": aggregation_policy
        }
        
        self._logger.info(f"Set retention policy for {data_type}: {retention_days} days, {aggregation_policy} aggregation")
    
    def cleanup_old_data(self, force: bool = False) -> Dict[str, int]:
        """
        Clean up old data based on retention policies.
        
        Args:
            force: Force cleanup even if interval has not elapsed
            
        Returns:
            Dictionary containing counts of deleted items by data type
        """
        if not self.enabled:
            self._logger.debug(f"StorageManager is disabled, skipping cleanup_old_data")
            return {}
        
        # Check if cleanup is needed
        now = time.time()
        if not force and now - self._last_cleanup_time < self._cleanup_interval_seconds:
            self._logger.debug(f"Skipping cleanup, last cleanup was {now - self._last_cleanup_time} seconds ago")
            return {}
        
        self._last_cleanup_time = now
        
        # Cleanup metrics
        metrics_deleted = self._cleanup_metrics()
        
        # Cleanup events
        events_deleted = self._cleanup_events()
        
        # Cleanup time series
        time_series_deleted = self._cleanup_time_series()
        
        result = {
            "metrics": metrics_deleted,
            "events": events_deleted,
            "time_series": time_series_deleted
        }
        
        self._logger.info(f"Cleaned up old data: {result}")
        return result
    
    def _check_cleanup(self) -> None:
        """Check if cleanup is needed and perform if necessary."""
        now = time.time()
        if now - self._last_cleanup_time >= self._cleanup_interval_seconds:
            self.cleanup_old_data()
    
    def _cleanup_metrics(self) -> int:
        """
        Clean up old metrics based on retention policy.
        
        Returns:
            Number of deleted metrics
        """
        # Get retention policy
        policy = self.get_retention_policy("metrics")
        retention_days = policy["retention_days"]
        aggregation_policy = policy["aggregation_policy"]
        
        # Calculate cutoff time
        cutoff_time = datetime.now() - timedelta(days=retention_days)
        
        # TODO: Implement actual cleanup logic
        # This would typically involve:
        # 1. Aggregating data older than cutoff time based on aggregation policy
        # 2. Deleting raw data older than cutoff time
        
        # For now, just log the operation
        self._logger.info(f"Would delete metrics older than {cutoff_time} with {aggregation_policy} aggregation")
        
        return 0
    
    def _cleanup_events(self) -> int:
        """
        Clean up old events based on retention policy.
        
        Returns:
            Number of deleted events
        """
        # Get retention policy
        policy = self.get_retention_policy("events")
        retention_days = policy["retention_days"]
        
        # Calculate cutoff time
        cutoff_time = datetime.now() - timedelta(days=retention_days)
        
        # TODO: Implement actual cleanup logic
        # This would typically involve deleting events older than cutoff time
        
        # For now, just log the operation
        self._logger.info(f"Would delete events older than {cutoff_time}")
        
        return 0
    
    def _cleanup_time_series(self) -> int:
        """
        Clean up old time series data based on retention policy.
        
        Returns:
            Number of deleted time series data points
        """
        # Get retention policy
        policy = self.get_retention_policy("time_series")
        retention_days = policy["retention_days"]
        aggregation_policy = policy["aggregation_policy"]
        
        # Calculate cutoff time
        cutoff_time = datetime.now() - timedelta(days=retention_days)
        
        # TODO: Implement actual cleanup logic
        # This would typically involve:
        # 1. Aggregating data older than cutoff time based on aggregation policy
        # 2. Deleting raw data older than cutoff time
        
        # For now, just log the operation
        self._logger.info(f"Would delete time series data older than {cutoff_time} with {aggregation_policy} aggregation")
        
        return 0

# Create global storage manager instance
storage_manager = StorageManager()
