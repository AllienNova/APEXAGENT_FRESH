"""
Collection module for the Advanced Analytics system.

This module provides data collection capabilities for tracking usage,
performance, events, and business metrics.
"""

import logging
import uuid
from typing import Dict, Any, List, Optional, Union
from datetime import datetime

from ..core.core import AnalyticsComponent, DataCategory, MetricType, SecurityClassification

logger = logging.getLogger(__name__)

class BaseCollector:
    """
    Base class for all data collectors.
    
    This class provides common functionality for data collectors.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize the base collector.
        
        Args:
            config: Configuration dictionary for the collector
        """
        self.config = config or {}
        self.enabled = self.config.get('enabled', True)
        logger.debug(f"Initialized {self.__class__.__name__} (enabled={self.enabled})")
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """
        Initialize or reinitialize the collector with new configuration.
        
        Args:
            config: Configuration dictionary for the collector
        """
        self.config = config
        self.enabled = config.get('enabled', True)
        logger.debug(f"Reinitialized {self.__class__.__name__} (enabled={self.enabled})")
    
    def _generate_id(self) -> str:
        """
        Generate a unique ID.
        
        Returns:
            Unique ID string
        """
        return str(uuid.uuid4())
    
    def _get_timestamp(self) -> int:
        """
        Get the current timestamp.
        
        Returns:
            Current timestamp in milliseconds
        """
        import time
        return int(time.time() * 1000)


class UsageCollector(BaseCollector):
    """
    Collector for resource usage data.
    
    This class provides methods for tracking resource usage across the system.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize the usage collector.
        
        Args:
            config: Configuration dictionary for the collector
        """
        super().__init__(config)
        self.usage_records = []
        logger.info("Initialized UsageCollector")
    
    def record_usage(self, user_id: str, resource_type: str, quantity: Union[int, float],
                    metadata: Dict[str, Any] = None) -> str:
        """
        Record usage of a resource.
        
        Args:
            user_id: ID of the user
            resource_type: Type of resource being used
            quantity: Amount of resource consumed
            metadata: Additional metadata about the usage
            
        Returns:
            ID of the recorded usage event
        """
        if not self.enabled:
            logger.debug("UsageCollector is disabled, skipping record_usage")
            return self._generate_id()
        
        usage_id = self._generate_id()
        timestamp = self._get_timestamp()
        
        usage_record = {
            'id': usage_id,
            'user_id': user_id,
            'resource_type': resource_type,
            'quantity': quantity,
            'timestamp': timestamp,
            'metadata': metadata or {}
        }
        
        self.usage_records.append(usage_record)
        logger.debug(f"Recorded usage: {resource_type}={quantity} for user {user_id}")
        
        return usage_id
    
    def get_usage_records(self, user_id: Optional[str] = None,
                         resource_type: Optional[str] = None,
                         start_time: Optional[int] = None,
                         end_time: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Get usage records matching the specified criteria.
        
        Args:
            user_id: Optional user ID to filter records
            resource_type: Optional resource type to filter records
            start_time: Optional start time (in milliseconds) to filter records
            end_time: Optional end time (in milliseconds) to filter records
            
        Returns:
            List of matching usage records
        """
        if not self.enabled:
            logger.debug("UsageCollector is disabled, returning empty list")
            return []
        
        filtered_records = self.usage_records
        
        if user_id is not None:
            filtered_records = [r for r in filtered_records if r['user_id'] == user_id]
        
        if resource_type is not None:
            filtered_records = [r for r in filtered_records if r['resource_type'] == resource_type]
        
        if start_time is not None:
            filtered_records = [r for r in filtered_records if r['timestamp'] >= start_time]
        
        if end_time is not None:
            filtered_records = [r for r in filtered_records if r['timestamp'] <= end_time]
        
        return filtered_records


class PerformanceCollector(BaseCollector):
    """
    Collector for performance metrics.
    
    This class provides methods for tracking performance metrics across the system.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize the performance collector.
        
        Args:
            config: Configuration dictionary for the collector
        """
        super().__init__(config)
        self.performance_records = []
        logger.info("Initialized PerformanceCollector")
    
    def record_performance(self, component: str, operation: str, duration_ms: float,
                          success: bool, metadata: Dict[str, Any] = None) -> str:
        """
        Record a performance metric.
        
        Args:
            component: Name of the component
            operation: Name of the operation
            duration_ms: Duration of the operation in milliseconds
            success: Whether the operation was successful
            metadata: Additional metadata about the operation
            
        Returns:
            ID of the recorded performance metric
        """
        if not self.enabled:
            logger.debug("PerformanceCollector is disabled, skipping record_performance")
            return self._generate_id()
        
        perf_id = self._generate_id()
        timestamp = self._get_timestamp()
        
        perf_record = {
            'id': perf_id,
            'component': component,
            'operation': operation,
            'duration_ms': duration_ms,
            'success': success,
            'timestamp': timestamp,
            'metadata': metadata or {}
        }
        
        self.performance_records.append(perf_record)
        logger.debug(f"Recorded performance: {component}.{operation}={duration_ms}ms (success={success})")
        
        return perf_id
    
    def get_performance_records(self, component: Optional[str] = None,
                              operation: Optional[str] = None,
                              success: Optional[bool] = None,
                              start_time: Optional[int] = None,
                              end_time: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Get performance records matching the specified criteria.
        
        Args:
            component: Optional component name to filter records
            operation: Optional operation name to filter records
            success: Optional success flag to filter records
            start_time: Optional start time (in milliseconds) to filter records
            end_time: Optional end time (in milliseconds) to filter records
            
        Returns:
            List of matching performance records
        """
        if not self.enabled:
            logger.debug("PerformanceCollector is disabled, returning empty list")
            return []
        
        filtered_records = self.performance_records
        
        if component is not None:
            filtered_records = [r for r in filtered_records if r['component'] == component]
        
        if operation is not None:
            filtered_records = [r for r in filtered_records if r['operation'] == operation]
        
        if success is not None:
            filtered_records = [r for r in filtered_records if r['success'] == success]
        
        if start_time is not None:
            filtered_records = [r for r in filtered_records if r['timestamp'] >= start_time]
        
        if end_time is not None:
            filtered_records = [r for r in filtered_records if r['timestamp'] <= end_time]
        
        return filtered_records


class BusinessMetricsCollector(BaseCollector):
    """
    Collector for business metrics.
    
    This class provides methods for tracking business metrics across the system.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize the business metrics collector.
        
        Args:
            config: Configuration dictionary for the collector
        """
        super().__init__(config)
        self.metric_records = []
        logger.info("Initialized BusinessMetricsCollector")
    
    def record_metric(self, metric_name: str, value: Union[int, float],
                     dimensions: Dict[str, str] = None) -> str:
        """
        Record a business metric.
        
        Args:
            metric_name: Name of the metric
            value: Value of the metric
            dimensions: Dimensions for the metric (e.g., region, product)
            
        Returns:
            ID of the recorded metric
        """
        if not self.enabled:
            logger.debug("BusinessMetricsCollector is disabled, skipping record_metric")
            return self._generate_id()
        
        metric_id = self._generate_id()
        timestamp = self._get_timestamp()
        
        metric_record = {
            'id': metric_id,
            'metric_name': metric_name,
            'value': value,
            'dimensions': dimensions or {},
            'timestamp': timestamp
        }
        
        self.metric_records.append(metric_record)
        logger.debug(f"Recorded business metric: {metric_name}={value}")
        
        return metric_id
    
    def get_metric_records(self, metric_name: Optional[str] = None,
                          dimensions: Dict[str, str] = None,
                          start_time: Optional[int] = None,
                          end_time: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Get metric records matching the specified criteria.
        
        Args:
            metric_name: Optional metric name to filter records
            dimensions: Optional dimensions to filter records
            start_time: Optional start time (in milliseconds) to filter records
            end_time: Optional end time (in milliseconds) to filter records
            
        Returns:
            List of matching metric records
        """
        if not self.enabled:
            logger.debug("BusinessMetricsCollector is disabled, returning empty list")
            return []
        
        filtered_records = self.metric_records
        
        if metric_name is not None:
            filtered_records = [r for r in filtered_records if r['metric_name'] == metric_name]
        
        if dimensions is not None:
            filtered_records = [
                r for r in filtered_records if all(
                    r['dimensions'].get(k) == v for k, v in dimensions.items()
                )
            ]
        
        if start_time is not None:
            filtered_records = [r for r in filtered_records if r['timestamp'] >= start_time]
        
        if end_time is not None:
            filtered_records = [r for r in filtered_records if r['timestamp'] <= end_time]
        
        return filtered_records


class EventCollector(BaseCollector):
    """
    Collector for application events.
    
    This class provides methods for tracking events across the system.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize the event collector.
        
        Args:
            config: Configuration dictionary for the collector
        """
        super().__init__(config)
        self.event_records = []
        logger.info("Initialized EventCollector")
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """
        Initialize or reinitialize the event collector with new configuration.
        
        Args:
            config: Configuration dictionary for the collector
        """
        super().initialize(config)
        # Additional event collector specific initialization can be added here
        logger.debug(f"Reinitialized EventCollector with config: {config}")
    
    def record_event(self, event_type: str, source: str = None, details: Dict[str, Any] = None,
                    dimensions: Dict[str, Any] = None, user_id: Optional[str] = None) -> str:
        """
        Record an application event.
        
        Args:
            event_type: Type of the event
            source: Source of the event
            details: Details associated with the event
            dimensions: Dimensions for the event
            user_id: ID of the user associated with the event (if applicable)
            
        Returns:
            ID of the recorded event
        """
        if not self.enabled:
            logger.debug("EventCollector is disabled, skipping record_event")
            return self._generate_id()
        
        event_id = self._generate_id()
        timestamp = self._get_timestamp()
        
        event_record = {
            'id': event_id,
            'event_type': event_type,
            'source': source,
            'details': details or {},
            'dimensions': dimensions or {},
            'user_id': user_id,
            'timestamp': timestamp
        }
        
        self.event_records.append(event_record)
        logger.debug(f"Recorded event: {event_type} from {source} for user {user_id}")
        
        return event_id
    
    def get_event_records(self, event_types: List[str] = None,
                         sources: List[str] = None,
                         user_id: Optional[str] = None,
                         dimensions: Dict[str, Any] = None,
                         start_time: Optional[int] = None,
                         end_time: Optional[int] = None,
                         limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get event records matching the specified criteria.
        
        Args:
            event_types: Optional list of event types to filter records
            sources: Optional list of sources to filter records
            user_id: Optional user ID to filter records
            dimensions: Optional dimensions to filter records
            start_time: Optional start time (in milliseconds) to filter records
            end_time: Optional end time (in milliseconds) to filter records
            limit: Maximum number of records to return
            
        Returns:
            List of matching event records
        """
        if not self.enabled:
            logger.debug("EventCollector is disabled, returning empty list")
            return []
        
        filtered_records = self.event_records
        
        if event_types is not None:
            filtered_records = [r for r in filtered_records if r['event_type'] in event_types]
        
        if sources is not None:
            filtered_records = [r for r in filtered_records if r['source'] in sources]
        
        if user_id is not None:
            filtered_records = [r for r in filtered_records if r['user_id'] == user_id]
        
        if dimensions is not None:
            filtered_records = [
                r for r in filtered_records if all(
                    r['dimensions'].get(k) == v for k, v in dimensions.items()
                )
            ]
        
        if start_time is not None:
            filtered_records = [r for r in filtered_records if r['timestamp'] >= start_time]
        
        if end_time is not None:
            filtered_records = [r for r in filtered_records if r['timestamp'] <= end_time]
        
        # Sort by timestamp (newest first) and apply limit
        filtered_records = sorted(filtered_records, key=lambda r: r['timestamp'], reverse=True)
        filtered_records = filtered_records[:limit]
        
        return filtered_records


class MetricCollector(AnalyticsComponent):
    """
    Collector for system and application metrics.
    
    This class provides methods for collecting, aggregating, and retrieving
    metrics from various components of the system.
    """
    
    def __init__(self, name: str = "metric_collector"):
        """
        Initialize the metric collector.
        
        Args:
            name: Name of the collector component
        """
        super().__init__(name)
        self.metrics = {}
        self.metric_history = {}
        self.retention_period_days = 30
        self.aggregation_intervals = {
            "1m": 60,         # 1 minute in seconds
            "5m": 300,        # 5 minutes in seconds
            "15m": 900,       # 15 minutes in seconds
            "1h": 3600,       # 1 hour in seconds
            "1d": 86400,      # 1 day in seconds
            "1w": 604800,     # 1 week in seconds
        }
        self._logger = logging.getLogger(f"{__name__}.{name}")
        self._logger.info(f"Initialized MetricCollector: {name}")
    
    def initialize(self, config: Dict[str, Any]) -> None:
        """
        Initialize the metric collector with configuration.
        
        Args:
            config: Configuration dictionary for the collector
        """
        self.retention_period_days = config.get("retention_period_days", 30)
        
        # Configure custom aggregation intervals if provided
        if "aggregation_intervals" in config:
            self.aggregation_intervals.update(config["aggregation_intervals"])
        
        self._logger.debug(f"Initialized MetricCollector with config: {config}")
    
    def shutdown(self) -> None:
        """
        Shutdown the metric collector.
        
        This method is called when the system is shutting down to perform
        any necessary cleanup operations.
        """
        # Perform any necessary cleanup
        self.metrics = {}
        self.metric_history = {}
        self._logger.info(f"Shutdown MetricCollector: {self.name}")
    
    def increment_counter(self, metric_name: str, dimensions: Dict[str, str] = None, value: int = 1) -> None:
        """
        Increment a counter metric.
        
        Args:
            metric_name: Name of the metric
            dimensions: Dimensions for the metric (e.g., region, product)
            value: Amount to increment by (default: 1)
        """
        metric_key = self._get_metric_key(metric_name, dimensions)
        
        if metric_key not in self.metrics:
            self.metrics[metric_key] = {
                "name": metric_name,
                "dimensions": dimensions or {},
                "type": "counter",
                "value": 0,
                "last_updated": self._get_timestamp()
            }
        
        self.metrics[metric_key]["value"] += value
        self.metrics[metric_key]["last_updated"] = self._get_timestamp()
        
        # Record in history
        self._record_metric_history(metric_key, self.metrics[metric_key]["value"])
    
    def decrement_counter(self, metric_name: str, dimensions: Dict[str, str] = None, value: int = 1) -> None:
        """
        Decrement a counter metric.
        
        Args:
            metric_name: Name of the metric
            dimensions: Dimensions for the metric (e.g., region, product)
            value: Amount to decrement by (default: 1)
        """
        metric_key = self._get_metric_key(metric_name, dimensions)
        
        if metric_key not in self.metrics:
            self.metrics[metric_key] = {
                "name": metric_name,
                "dimensions": dimensions or {},
                "type": "counter",
                "value": 0,
                "last_updated": self._get_timestamp()
            }
        
        self.metrics[metric_key]["value"] -= value
        self.metrics[metric_key]["last_updated"] = self._get_timestamp()
        
        # Record in history
        self._record_metric_history(metric_key, self.metrics[metric_key]["value"])
    
    def set_gauge(self, metric_name: str, dimensions: Dict[str, str] = None, value: Union[int, float] = 0) -> None:
        """
        Set a gauge metric.
        
        Args:
            metric_name: Name of the metric
            dimensions: Dimensions for the metric (e.g., region, product)
            value: Value to set
        """
        metric_key = self._get_metric_key(metric_name, dimensions)
        
        if metric_key not in self.metrics:
            self.metrics[metric_key] = {
                "name": metric_name,
                "dimensions": dimensions or {},
                "type": "gauge",
                "value": 0,
                "last_updated": self._get_timestamp()
            }
        
        self.metrics[metric_key]["value"] = value
        self.metrics[metric_key]["last_updated"] = self._get_timestamp()
        
        # Record in history
        self._record_metric_history(metric_key, value)
    
    def increment_gauge(self, metric_name: str, dimensions: Dict[str, str] = None, value: Union[int, float] = 1) -> None:
        """
        Increment a gauge metric.
        
        Args:
            metric_name: Name of the metric
            dimensions: Dimensions for the metric (e.g., region, product)
            value: Amount to increment by (default: 1)
        """
        metric_key = self._get_metric_key(metric_name, dimensions)
        
        if metric_key not in self.metrics:
            self.metrics[metric_key] = {
                "name": metric_name,
                "dimensions": dimensions or {},
                "type": "gauge",
                "value": 0,
                "last_updated": self._get_timestamp()
            }
        
        self.metrics[metric_key]["value"] += value
        self.metrics[metric_key]["last_updated"] = self._get_timestamp()
        
        # Record in history
        self._record_metric_history(metric_key, self.metrics[metric_key]["value"])
    
    def decrement_gauge(self, metric_name: str, dimensions: Dict[str, str] = None, value: Union[int, float] = 1) -> None:
        """
        Decrement a gauge metric.
        
        Args:
            metric_name: Name of the metric
            dimensions: Dimensions for the metric (e.g., region, product)
            value: Amount to decrement by (default: 1)
        """
        metric_key = self._get_metric_key(metric_name, dimensions)
        
        if metric_key not in self.metrics:
            self.metrics[metric_key] = {
                "name": metric_name,
                "dimensions": dimensions or {},
                "type": "gauge",
                "value": 0,
                "last_updated": self._get_timestamp()
            }
        
        self.metrics[metric_key]["value"] -= value
        self.metrics[metric_key]["last_updated"] = self._get_timestamp()
        
        # Record in history
        self._record_metric_history(metric_key, self.metrics[metric_key]["value"])
    
    def record_histogram(self, metric_name: str, dimensions: Dict[str, str] = None, value: Union[int, float] = 0) -> None:
        """
        Record a value in a histogram metric.
        
        Args:
            metric_name: Name of the metric
            dimensions: Dimensions for the metric (e.g., region, product)
            value: Value to record
        """
        metric_key = self._get_metric_key(metric_name, dimensions)
        
        if metric_key not in self.metrics:
            self.metrics[metric_key] = {
                "name": metric_name,
                "dimensions": dimensions or {},
                "type": "histogram",
                "values": [],
                "count": 0,
                "sum": 0,
                "min": float('inf'),
                "max": float('-inf'),
                "last_updated": self._get_timestamp()
            }
        
        # Update histogram statistics
        self.metrics[metric_key]["values"].append(value)
        self.metrics[metric_key]["count"] += 1
        self.metrics[metric_key]["sum"] += value
        self.metrics[metric_key]["min"] = min(self.metrics[metric_key]["min"], value)
        self.metrics[metric_key]["max"] = max(self.metrics[metric_key]["max"], value)
        self.metrics[metric_key]["last_updated"] = self._get_timestamp()
        
        # Record in history (we record the value itself, not the histogram stats)
        self._record_metric_history(metric_key, value)
    
    def get_metric(self, metric_name: str, dimensions: Dict[str, str] = None) -> Dict[str, Any]:
        """
        Get the current value of a metric.
        
        Args:
            metric_name: Name of the metric
            dimensions: Dimensions for the metric (e.g., region, product)
            
        Returns:
            Metric data or None if not found
        """
        metric_key = self._get_metric_key(metric_name, dimensions)
        return self.metrics.get(metric_key)
    
    def get_metric_history(self, metric_name: str, dimensions: Dict[str, str] = None,
                          interval: str = "1h", start_time: Optional[int] = None,
                          end_time: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Get the history of a metric.
        
        Args:
            metric_name: Name of the metric
            dimensions: Dimensions for the metric (e.g., region, product)
            interval: Aggregation interval (e.g., "1m", "5m", "1h", "1d")
            start_time: Optional start time (in milliseconds) to filter records
            end_time: Optional end time (in milliseconds) to filter records
            
        Returns:
            List of metric data points
        """
        metric_key = self._get_metric_key(metric_name, dimensions)
        
        if metric_key not in self.metric_history:
            return []
        
        # Get raw history
        history = self.metric_history[metric_key]
        
        # Filter by time range
        if start_time is not None:
            history = [h for h in history if h["timestamp"] >= start_time]
        
        if end_time is not None:
            history = [h for h in history if h["timestamp"] <= end_time]
        
        # If interval is not specified or not recognized, return raw history
        if interval not in self.aggregation_intervals:
            return history
        
        # Aggregate by interval
        interval_seconds = self.aggregation_intervals[interval]
        aggregated_history = self._aggregate_metric_history(history, interval_seconds)
        
        return aggregated_history
    
    def _get_metric_key(self, metric_name: str, dimensions: Dict[str, str] = None) -> str:
        """
        Generate a unique key for a metric based on name and dimensions.
        
        Args:
            metric_name: Name of the metric
            dimensions: Dimensions for the metric (e.g., region, product)
            
        Returns:
            Unique metric key
        """
        if not dimensions:
            return metric_name
        
        # Sort dimensions by key to ensure consistent key generation
        sorted_dimensions = sorted(dimensions.items())
        dimension_str = ",".join(f"{k}={v}" for k, v in sorted_dimensions)
        
        return f"{metric_name}[{dimension_str}]"
    
    def _record_metric_history(self, metric_key: str, value: Union[int, float]) -> None:
        """
        Record a metric value in the history.
        
        Args:
            metric_key: Unique key for the metric
            value: Value to record
        """
        if metric_key not in self.metric_history:
            self.metric_history[metric_key] = []
        
        timestamp = self._get_timestamp()
        
        self.metric_history[metric_key].append({
            "timestamp": timestamp,
            "value": value
        })
        
        # Prune old history
        self._prune_metric_history(metric_key)
    
    def _prune_metric_history(self, metric_key: str) -> None:
        """
        Prune old metric history based on retention period.
        
        Args:
            metric_key: Unique key for the metric
        """
        if metric_key not in self.metric_history:
            return
        
        # Calculate cutoff timestamp
        retention_seconds = self.retention_period_days * 86400  # days to seconds
        cutoff_timestamp = self._get_timestamp() - (retention_seconds * 1000)  # to milliseconds
        
        # Filter out old records
        self.metric_history[metric_key] = [
            h for h in self.metric_history[metric_key] if h["timestamp"] >= cutoff_timestamp
        ]
    
    def _aggregate_metric_history(self, history: List[Dict[str, Any]], interval_seconds: int) -> List[Dict[str, Any]]:
        """
        Aggregate metric history by time interval.
        
        Args:
            history: Raw metric history
            interval_seconds: Aggregation interval in seconds
            
        Returns:
            Aggregated metric history
        """
        if not history:
            return []
        
        # Convert interval to milliseconds
        interval_ms = interval_seconds * 1000
        
        # Group by interval
        intervals = {}
        for record in history:
            timestamp = record["timestamp"]
            interval_start = (timestamp // interval_ms) * interval_ms
            
            if interval_start not in intervals:
                intervals[interval_start] = []
            
            intervals[interval_start].append(record["value"])
        
        # Aggregate values in each interval
        aggregated = []
        for interval_start, values in sorted(intervals.items()):
            count = len(values)
            sum_value = sum(values)
            min_value = min(values)
            max_value = max(values)
            avg_value = sum_value / count if count > 0 else 0
            
            aggregated.append({
                "timestamp": interval_start,
                "interval": interval_seconds,
                "count": count,
                "sum": sum_value,
                "min": min_value,
                "max": max_value,
                "avg": avg_value
            })
        
        return aggregated
    
    def _get_timestamp(self) -> int:
        """
        Get the current timestamp.
        
        Returns:
            Current timestamp in milliseconds
        """
        import time
        return int(time.time() * 1000)
