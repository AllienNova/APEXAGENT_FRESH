"""
Validation runner script for the Advanced Analytics system.

This script executes the validation tests for the analytics system
and generates a comprehensive validation report.
"""

import json
import logging
import sys
import os
from datetime import datetime

# Add the project root to the Python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from src.analytics.analytics import AdvancedAnalytics
from src.analytics.tests.validation import AnalyticsValidator

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def main():
    """
    Main function to run the validation tests.
    """
    logger.info("Starting Advanced Analytics validation")
    
    # Initialize the analytics system with test configuration
    config = {
        'core': {'test_mode': True},
        'storage': {'in_memory': True},
        'auth_integration': {'mock': True},
        'subscription_integration': {'mock': True},
        'llm_integration': {'mock': True},
        'data_protection_integration': {'mock': True}
    }
    
    analytics = AdvancedAnalytics(config)
    validator = AnalyticsValidator(analytics)
    
    # Run all validation tests
    logger.info("Running validation tests")
    results = validator.validate_all()
    
    # Generate validation report
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    report_file = f"analytics_validation_report_{timestamp}.json"
    
    with open(report_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    logger.info(f"Validation report saved to {report_file}")
    
    # Print summary
    summary = results['summary']
    print("\n=== VALIDATION SUMMARY ===")
    print(f"Total tests: {summary['total_tests']}")
    print(f"Passed tests: {summary['passed_tests']}")
    print(f"Success rate: {summary['success_rate'] * 100:.2f}%")
    print(f"Overall status: {summary['status']}")
    print("=========================\n")
    
    # Print category results
    for category, category_results in results.items():
        if category != 'summary':
            passed = category_results['passed']
            total = category_results['total']
            print(f"{category.upper()}: {passed}/{total} tests passed ({category_results['success_rate'] * 100:.2f}%)")
    
    return summary['status'] == 'PASS'

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
