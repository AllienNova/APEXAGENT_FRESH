"""
Security Package for Dr. TARDIS Gemini Live API Integration.

This package provides comprehensive security and compliance features for the
Dr. TARDIS system, including secure data handling, privacy controls,
audit capabilities, and security incident response procedures.

Author: Manus Agent
Date: May 26, 2025
"""

from enum import Enum, auto
from typing import Dict, List, Optional, Any, Union

# Export public interfaces
__all__ = [
    'SecurityManager',
    'PrivacyManager',
    'AuditManager',
    'IncidentResponseManager',
    'SecurityLevel',
    'DataCategory',
    'ConsentStatus',
    'AuditEventType',
    'IncidentSeverity'
]

# Enumerations for security and compliance
class SecurityLevel(Enum):
    """Security levels for data and operations."""
    PUBLIC = 0
    INTERNAL = 1
    CONFIDENTIAL = 2
    RESTRICTED = 3
    CRITICAL = 4

class DataCategory(Enum):
    """Categories of data for privacy and compliance purposes."""
    SYSTEM = auto()
    DIAGNOSTIC = auto()
    USER_PROVIDED = auto()
    GENERATED = auto()
    BIOMETRIC = auto()
    HEALTH = auto()
    FINANCIAL = auto()
    LOCATION = auto()

class ConsentStatus(Enum):
    """User consent status for data processing."""
    GRANTED = auto()
    DENIED = auto()
    PARTIAL = auto()
    EXPIRED = auto()
    UNKNOWN = auto()

class AuditEventType(Enum):
    """Types of events to be audited."""
    AUTHENTICATION = auto()
    AUTHORIZATION = auto()
    DATA_ACCESS = auto()
    DATA_MODIFICATION = auto()
    SYSTEM_CHANGE = auto()
    SECURITY_EVENT = auto()
    COMPLIANCE_CHECK = auto()
    USER_CONSENT = auto()

class IncidentSeverity(Enum):
    """Severity levels for security incidents."""
    INFO = auto()
    LOW = auto()
    MEDIUM = auto()
    HIGH = auto()
    CRITICAL = auto()
