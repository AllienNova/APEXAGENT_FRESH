"""
Privacy Manager for Dr. TARDIS.

This module provides comprehensive privacy controls for the Dr. TARDIS system,
including user consent management, data minimization, and privacy policy enforcement.

Author: Manus Agent
Date: May 26, 2025
"""

import json
import logging
import time
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union

from src.security import ConsentStatus, DataCategory, SecurityLevel

class PrivacyAction(Enum):
    """Types of privacy-related actions."""
    COLLECT = "collect"
    STORE = "store"
    PROCESS = "process"
    SHARE = "share"
    DELETE = "delete"
    ANONYMIZE = "anonymize"
    EXPORT = "export"

class RetentionPolicy(Enum):
    """Data retention policies."""
    SESSION = "session"
    SHORT_TERM = "short_term"  # e.g., 30 days
    MEDIUM_TERM = "medium_term"  # e.g., 1 year
    LONG_TERM = "long_term"  # e.g., 7 years
    PERMANENT = "permanent"
    CUSTOM = "custom"  # Custom retention period

class PrivacyManager:
    """
    Manages privacy controls and user consent for Dr. TARDIS.
    
    This class provides comprehensive privacy management capabilities including:
    - User consent management
    - Data minimization and anonymization
    - Privacy policy enforcement
    - Data retention management
    - Privacy impact assessment
    """
    
    def __init__(self, storage_dir: Optional[Path] = None, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the PrivacyManager.
        
        Args:
            storage_dir: Directory for storing privacy-related data
            config: Configuration options for the privacy manager
        """
        self.storage_dir = storage_dir or Path("/tmp/dr_tardis_privacy")
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        
        # Default configuration
        self.config = {
            "default_retention": {
                RetentionPolicy.SESSION: 0,  # Until session ends
                RetentionPolicy.SHORT_TERM: 30,  # 30 days
                RetentionPolicy.MEDIUM_TERM: 365,  # 1 year
                RetentionPolicy.LONG_TERM: 2555,  # 7 years
                RetentionPolicy.PERMANENT: -1,  # No expiration
            },
            "consent_expiration_days": 365,  # 1 year
            "anonymization_threshold": 0.8,  # Threshold for considering data anonymized
            "required_consent_level": 0.7,  # Minimum consent level required for processing
            "data_minimization_enabled": True,
            "privacy_by_default": True,
        }
        
        # Update with provided config
        if config:
            self.config.update(config)
        
        # Initialize consent storage
        self.consent_store = {}
        self.load_consent_data()
        
        # Initialize logger
        self.logger = logging.getLogger("dr_tardis.privacy")
    
    def load_consent_data(self) -> None:
        """Load existing consent data or initialize empty store."""
        consent_path = self.storage_dir / "consent_store.json"
        
        if consent_path.exists():
            try:
                with open(consent_path, "r") as f:
                    self.consent_store = json.load(f)
                    
                    # Convert string dates back to datetime objects
                    for user_id, consents in self.consent_store.items():
                        for data_category, consent_info in consents.items():
                            if "timestamp" in consent_info:
                                consent_info["timestamp"] = datetime.fromisoformat(consent_info["timestamp"])
                            if "expiration" in consent_info and consent_info["expiration"]:
                                consent_info["expiration"] = datetime.fromisoformat(consent_info["expiration"])
            except (json.JSONDecodeError, IOError) as e:
                self.logger.error(f"Failed to load consent data: {e}")
                self.consent_store = {}
    
    def save_consent_data(self) -> None:
        """Save consent data to persistent storage."""
        consent_path = self.storage_dir / "consent_store.json"
        
        # Convert datetime objects to strings for JSON serialization
        serializable_store = {}
        for user_id, consents in self.consent_store.items():
            serializable_store[user_id] = {}
            for data_category, consent_info in consents.items():
                serializable_store[user_id][data_category] = consent_info.copy()
                if "timestamp" in consent_info:
                    serializable_store[user_id][data_category]["timestamp"] = consent_info["timestamp"].isoformat()
                if "expiration" in consent_info and consent_info["expiration"]:
                    serializable_store[user_id][data_category]["expiration"] = consent_info["expiration"].isoformat()
        
        try:
            with open(consent_path, "w") as f:
                json.dump(serializable_store, f)
        except IOError as e:
            self.logger.error(f"Failed to save consent data: {e}")
    
    def record_consent(self, user_id: str, data_category: Union[DataCategory, str], 
                      status: ConsentStatus, actions: List[PrivacyAction],
                      expiration_days: Optional[int] = None) -> bool:
        """
        Record user consent for data processing.
        
        Args:
            user_id: Identifier for the user
            data_category: Category of data the consent applies to
            status: Consent status (granted, denied, etc.)
            actions: List of actions the consent applies to
            expiration_days: Number of days until consent expires, or None for default
            
        Returns:
            True if consent was successfully recorded
        """
        # Convert string data category to enum if needed
        if isinstance(data_category, str):
            try:
                data_category = DataCategory[data_category]
            except KeyError:
                self.logger.error(f"Invalid data category: {data_category}")
                return False
        
        # Convert actions to strings for storage
        action_values = [a.value if isinstance(a, PrivacyAction) else a for a in actions]
        
        # Calculate expiration date
        expiration_days = expiration_days or self.config["consent_expiration_days"]
        expiration = datetime.now() + timedelta(days=expiration_days) if expiration_days > 0 else None
        
        # Initialize user in consent store if needed
        if user_id not in self.consent_store:
            self.consent_store[user_id] = {}
        
        # Record consent
        self.consent_store[user_id][data_category.name if isinstance(data_category, DataCategory) else data_category] = {
            "status": status.name if isinstance(status, ConsentStatus) else status,
            "actions": action_values,
            "timestamp": datetime.now(),
            "expiration": expiration,
        }
        
        # Save to persistent storage
        self.save_consent_data()
        
        return True
    
    def check_consent(self, user_id: str, data_category: Union[DataCategory, str], 
                     action: Union[PrivacyAction, str]) -> ConsentStatus:
        """
        Check if user has given consent for a specific action on a data category.
        
        Args:
            user_id: Identifier for the user
            data_category: Category of data to check consent for
            action: Action to check consent for
            
        Returns:
            Consent status for the specified action and data category
        """
        # Convert string data category to enum if needed
        if isinstance(data_category, str):
            try:
                data_category = DataCategory[data_category]
            except KeyError:
                self.logger.error(f"Invalid data category: {data_category}")
                return ConsentStatus.UNKNOWN
        
        # Convert action to string if needed
        action_str = action.value if isinstance(action, PrivacyAction) else action
        
        # Check if user exists in consent store
        if user_id not in self.consent_store:
            return ConsentStatus.UNKNOWN
        
        # Get data category name
        category_name = data_category.name if isinstance(data_category, DataCategory) else data_category
        
        # Check if consent exists for data category
        if category_name not in self.consent_store[user_id]:
            return ConsentStatus.UNKNOWN
        
        # Get consent info
        consent_info = self.consent_store[user_id][category_name]
        
        # Check if consent has expired
        if "expiration" in consent_info and consent_info["expiration"]:
            if isinstance(consent_info["expiration"], str):
                expiration = datetime.fromisoformat(consent_info["expiration"])
            else:
                expiration = consent_info["expiration"]
                
            if expiration < datetime.now():
                return ConsentStatus.EXPIRED
        
        # Check if action is included in consent
        if action_str not in consent_info["actions"]:
            return ConsentStatus.DENIED
        
        # Return consent status
        return ConsentStatus[consent_info["status"]] if isinstance(consent_info["status"], str) else consent_info["status"]
    
    def revoke_consent(self, user_id: str, data_category: Optional[Union[DataCategory, str]] = None) -> bool:
        """
        Revoke user consent for data processing.
        
        Args:
            user_id: Identifier for the user
            data_category: Category of data to revoke consent for, or None for all categories
            
        Returns:
            True if consent was successfully revoked
        """
        # Check if user exists in consent store
        if user_id not in self.consent_store:
            return False
        
        if data_category is None:
            # Revoke all consent for user
            self.consent_store[user_id] = {}
        else:
            # Convert string data category to enum if needed
            category_name = data_category.name if isinstance(data_category, DataCategory) else data_category
            
            # Revoke consent for specific data category
            if category_name in self.consent_store[user_id]:
                del self.consent_store[user_id][category_name]
        
        # Save to persistent storage
        self.save_consent_data()
        
        return True
    
    def anonymize_data(self, data: Dict[str, Any], data_category: DataCategory) -> Dict[str, Any]:
        """
        Anonymize data by removing or obfuscating personally identifiable information.
        
        Args:
            data: Data to anonymize
            data_category: Category of the data
            
        Returns:
            Anonymized data
        """
        import hashlib
        import re
        import uuid
        
        anonymized = data.copy()
        
        # Create consistent pseudonyms using deterministic hashing
        def generate_pseudonym(value: str, salt: str = "dr_tardis_salt") -> str:
            """Generate a consistent pseudonym for a value using hashing."""
            if not value:
                return ""
            hash_obj = hashlib.sha256(f"{value}{salt}".encode())
            return hash_obj.hexdigest()[:12]  # Use first 12 chars of hash
            
        # Regular expressions for identifying sensitive data patterns
        patterns = {
            "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            "phone": r'\b(\+\d{1,3}[\s-])?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b',
            "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
            "credit_card": r'\b(?:\d{4}[- ]?){3}\d{4}\b',
            "ip_address": r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',
            "date_of_birth": r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b'
        }
        
        # Track pseudonyms to ensure consistency across fields
        pseudonyms = {}
        
        # Apply different anonymization techniques based on data category
        if data_category == DataCategory.USER_PROVIDED:
            # Handle direct identifiers with pseudonymization
            direct_identifiers = ["name", "email", "phone", "address", "user_id", "username"]
            for field in direct_identifiers:
                if field in anonymized:
                    original = str(anonymized[field])
                    if original in pseudonyms:
                        anonymized[field] = pseudonyms[original]
                    else:
                        if field == "email" and "@" in original:
                            # Preserve domain part for emails
                            username, domain = original.split("@", 1)
                            pseudonym = f"{generate_pseudonym(username)}@{domain}"
                        else:
                            pseudonym = f"PSEUDONYM_{generate_pseudonym(original)}"
                        pseudonyms[original] = pseudonym
                        anonymized[field] = pseudonym
            
            # Scan all string values for patterns that might contain PII
            for field, value in anonymized.items():
                if isinstance(value, str):
                    # Check for and anonymize email patterns
                    value = re.sub(patterns["email"], 
                                  lambda m: pseudonyms.get(m.group(0), 
                                                          f"email_{generate_pseudonym(m.group(0))}@example.com"),
                                  value)
                    
                    # Check for and anonymize phone patterns
                    value = re.sub(patterns["phone"], 
                                  lambda m: pseudonyms.get(m.group(0), "XXX-XXX-XXXX"),
                                  value)
                    
                    # Check for and anonymize SSN patterns
                    value = re.sub(patterns["ssn"], "XXX-XX-XXXX", value)
                    
                    # Check for and anonymize credit card patterns
                    value = re.sub(patterns["credit_card"], "XXXX-XXXX-XXXX-XXXX", value)
                    
                    # Update the field with anonymized content
                    anonymized[field] = value
                    
        elif data_category == DataCategory.BIOMETRIC:
            # Completely anonymize biometric data
            # Replace with synthetic data that preserves statistical properties
            biometric_fields = {
                "fingerprint": lambda: str(uuid.uuid4()),
                "facial_recognition": lambda: {"anonymized_vector": [round(random.random(), 3) for _ in range(10)]},
                "voice_pattern": lambda: {"frequency_range": f"{random.randint(80, 120)}Hz-{random.randint(7000, 8000)}Hz"},
                "retina_scan": lambda: str(uuid.uuid4()),
                "height": lambda: round(random.uniform(150, 190), 1),  # cm
                "weight": lambda: round(random.uniform(50, 100), 1),   # kg
            }
            
            # Replace all biometric data with synthetic data
            for field in list(anonymized.keys()):
                if field in biometric_fields:
                    anonymized[field] = biometric_fields[field]()
                elif field not in ["id", "timestamp", "metadata"]:
                    # Remove any other fields that might contain biometric data
                    anonymized[field] = "[BIOMETRIC DATA REMOVED]"
            
            # Add metadata about anonymization
            anonymized["_anonymization_method"] = "synthetic_replacement"
            anonymized["_original_category"] = data_category.name
            
        elif data_category == DataCategory.HEALTH:
            # Anonymize health data while preserving statistical value
            health_fields = {
                "medical_records": True,
                "diagnosis": True,
                "medications": True,
                "allergies": True,
                "lab_results": True,
                "vital_signs": True,
                "medical_history": True
            }
            
            for field in anonymized:
                if field in health_fields:
                    if isinstance(anonymized[field], dict):
                        # For structured health data, preserve structure but anonymize values
                        for subfield in anonymized[field]:
                            if isinstance(anonymized[field][subfield], str):
                                # Replace specific identifiers but keep medical terms
                                anonymized[field][subfield] = re.sub(r'\b(patient|name|id)[:=]\s*\w+\b', 
                                                                   "[REDACTED]", 
                                                                   anonymized[field][subfield], 
                                                                   flags=re.IGNORECASE)
                    elif isinstance(anonymized[field], str):
                        # For text fields, replace specific identifiers but keep medical terms
                        anonymized[field] = re.sub(r'\b(patient|name|id)[:=]\s*\w+\b', 
                                                 "[REDACTED]", 
                                                 anonymized[field], 
                                                 flags=re.IGNORECASE)
                    elif isinstance(anonymized[field], list):
                        # For lists (like medications), keep the values but remove any identifiers
                        anonymized[field] = [
                            item if not any(p in str(item).lower() for p in ["name", "patient", "identifier"]) 
                            else "[REDACTED]" for item in anonymized[field]
                        ]
            
            # Generalize age information to age ranges
            if "age" in anonymized:
                age = anonymized["age"]
                if isinstance(age, (int, float)):
                    # Convert specific age to age range
                    age_ranges = [(0, 17, "0-17"), (18, 34, "18-34"), (35, 50, "35-50"), 
                                 (51, 65, "51-65"), (66, 120, "65+")]
                    for min_age, max_age, range_label in age_ranges:
                        if min_age <= age <= max_age:
                            anonymized["age"] = range_label
                            break
            
            # Generalize dates to month/year only
            date_fields = ["admission_date", "discharge_date", "procedure_date"]
            for field in date_fields:
                if field in anonymized and anonymized[field]:
                    try:
                        # Try to parse and generalize the date
                        date_obj = datetime.fromisoformat(str(anonymized[field]).replace("Z", "+00:00"))
                        anonymized[field] = date_obj.strftime("%Y-%m")  # Year-month only
                    except (ValueError, TypeError):
                        # If parsing fails, redact the field
                        anonymized[field] = "[DATE REDACTED]"
        
        elif data_category == DataCategory.FINANCIAL:
            # Anonymize financial data while preserving statistical patterns
            for field in anonymized:
                if field in ["account_number", "routing_number", "card_number"]:
                    # Completely mask account numbers
                    if isinstance(anonymized[field], str):
                        anonymized[field] = "X" * len(anonymized[field])
                elif field in ["balance", "amount", "transaction_amount"]:
                    # Round financial amounts to nearest 10 to preserve approximate values
                    if isinstance(anonymized[field], (int, float)):
                        anonymized[field] = round(anonymized[field] / 10) * 10
                elif field == "transactions":
                    # For transaction lists, anonymize each transaction
                    if isinstance(anonymized[field], list):
                        for i, transaction in enumerate(anonymized[field]):
                            if isinstance(transaction, dict):
                                # Anonymize transaction details
                                if "description" in transaction:
                                    transaction["description"] = f"Transaction {i+1}"
                                if "amount" in transaction and isinstance(transaction["amount"], (int, float)):
                                    transaction["amount"] = round(transaction["amount"] / 10) * 10
                                if "account" in transaction:
                                    transaction["account"] = "XXXX" + str(transaction["account"])[-4:] if transaction["account"] else "XXXX"
        
        elif data_category == DataCategory.LOCATION:
            # Anonymize location data by reducing precision
            location_fields = ["latitude", "longitude", "coordinates", "address", "location"]
            
            for field in anonymized:
                if field in location_fields:
                    if field in ["latitude", "longitude"] and isinstance(anonymized[field], (int, float)):
                        # Reduce coordinate precision to ~10km by truncating decimal places
                        anonymized[field] = round(anonymized[field], 1)
                    elif field == "coordinates" and isinstance(anonymized[field], (list, tuple)) and len(anonymized[field]) >= 2:
                        # Handle coordinate pairs
                        anonymized[field] = [round(c, 1) if isinstance(c, (int, float)) else c for c in anonymized[field][:2]]
                    elif field in ["address", "location"] and isinstance(anonymized[field], str):
                        # For addresses, keep only city/region level information
                        address_parts = anonymized[field].split(',')
                        if len(address_parts) > 1:
                            # Keep only city and country, remove street address
                            anonymized[field] = ','.join(address_parts[1:]).strip()
                        else:
                            anonymized[field] = "[LOCATION GENERALIZED]"
        
        # Add anonymization metadata
        anonymized["_anonymized"] = True
        anonymized["_anonymization_timestamp"] = datetime.now().isoformat()
        anonymized["_anonymization_version"] = "2.0"
        anonymized["_data_category"] = data_category.name
        
        return anonymized
    
    def calculate_anonymization_score(self, data: Dict[str, Any]) -> float:
        """
        Calculate how well data has been anonymized.
        
        Args:
            data: Data to evaluate
            
        Returns:
            Anonymization score between 0.0 (not anonymized) and 1.0 (fully anonymized)
        """
        import re
        
        # Check if data is already marked as anonymized
        if data.get("_anonymized", False):
            # If data has an anonymization version, use it to determine score
            version = data.get("_anonymization_version", "1.0")
            if version == "2.0":
                return 1.0
            elif version == "1.0":
                return 0.9  # Older anonymization version may not be as thorough
            return 0.95  # Default for marked anonymized data without version
        
        # Define patterns for identifying PII
        pii_patterns = {
            "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            "phone": r'\b(\+\d{1,3}[\s-])?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b',
            "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
            "credit_card": r'\b(?:\d{4}[- ]?){3}\d{4}\b',
            "ip_address": r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',
            "date_of_birth": r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b',
            "address": r'\b\d+\s+[A-Za-z0-9\s,]+(?:Avenue|Lane|Road|Boulevard|Drive|Street|Ave|Dr|Rd|Blvd|Ln|St)\.?\b',
            "name_pattern": r'\b(?:Mr\.|Mrs\.|Ms\.|Dr\.)\s+[A-Z][a-z]+\b'
        }
        
        # Direct identifier fields
        direct_identifiers = {
            "high_sensitivity": ["ssn", "social_security", "passport_number", "driver_license", "national_id", 
                               "credit_card", "card_number", "account_number", "password", "secret_key"],
            "medium_sensitivity": ["name", "full_name", "first_name", "last_name", "email", "phone", "phone_number", 
                                 "address", "street_address", "birth_date", "date_of_birth", "birthdate"],
            "low_sensitivity": ["user_id", "username", "ip_address", "device_id", "cookie_id", "session_id", 
                              "postal_code", "zip_code", "zip", "age", "gender"]
        }
        
        # Weights for different types of identifiers
        weights = {
            "high_sensitivity": 0.5,
            "medium_sensitivity": 0.3,
            "low_sensitivity": 0.2,
            "pattern_match": 0.4
        }
        
        # Initialize counters
        total_fields = 0
        anonymized_fields = 0
        total_weight = 0
        weighted_anonymized = 0
        
        # Check direct identifier fields
        for sensitivity, fields in direct_identifiers.items():
            for field in fields:
                if field in data:
                    total_fields += 1
                    total_weight += weights[sensitivity]
                    
                    # Check if field is anonymized
                    value = data[field]
                    if value is None or value == "" or value == "[REDACTED]" or "PSEUDONYM_" in str(value):
                        anonymized_fields += 1
                        weighted_anonymized += weights[sensitivity]
                    elif isinstance(value, str) and (all(c == 'X' for c in value) or value == "[ANONYMIZED]"):
                        anonymized_fields += 1
                        weighted_anonymized += weights[sensitivity]
                    elif isinstance(value, str) and len(value) > 3 and value.startswith("[") and value.endswith("]"):
                        # Likely a redaction placeholder
                        anonymized_fields += 1
                        weighted_anonymized += weights[sensitivity]
        
        # Check for PII patterns in string values
        pattern_matches = 0
        pattern_fields = 0
        
        for field, value in data.items():
            if isinstance(value, str) and len(value) > 5:
                pattern_fields += 1
                total_weight += weights["pattern_match"]
                
                # Check for PII patterns
                has_pii = False
                for pattern_name, pattern in pii_patterns.items():
                    if re.search(pattern, value):
                        has_pii = True
                        pattern_matches += 1
                        break
                
                if not has_pii:
                    weighted_anonymized += weights["pattern_match"]
        
        # Calculate final score
        if total_weight == 0:
            # No sensitive fields found, consider it fully anonymized
            return 1.0
        
        base_score = weighted_anonymized / total_weight
        
        # Apply penalties for specific issues
        penalties = 0
        
        # Penalty for having high sensitivity fields with values
        high_sensitivity_with_values = sum(1 for field in direct_identifiers["high_sensitivity"] 
                                         if field in data and data[field] and not (
                                             isinstance(data[field], str) and (
                                                 data[field] == "[REDACTED]" or 
                                                 "PSEUDONYM_" in data[field] or
                                                 all(c == 'X' for c in data[field])
                                             )
                                         ))
        if high_sensitivity_with_values > 0:
            penalties += 0.3
        
        # Penalty for having multiple medium sensitivity fields with values
        medium_sensitivity_with_values = sum(1 for field in direct_identifiers["medium_sensitivity"] 
                                           if field in data and data[field] and not (
                                               isinstance(data[field], str) and (
                                                   data[field] == "[REDACTED]" or 
                                                   "PSEUDONYM_" in data[field] or
                                                   all(c == 'X' for c in data[field])
                                               )
                                           ))
        if medium_sensitivity_with_values >= 2:
            penalties += 0.2
        
        # Apply penalties but ensure score stays between 0 and 1
        final_score = max(0.0, min(1.0, base_score - penalties))
        
        return final_score
    
    def is_sufficiently_anonymized(self, data: Dict[str, Any]) -> bool:
        """
        Check if data is sufficiently anonymized according to configuration threshold.
        
        Args:
            data: Data to evaluate
            
        Returns:
            True if data meets anonymization threshold
        """
        score = self.calculate_anonymization_score(data)
        return score >= self.config["anonymization_threshold"]
    
    def apply_data_minimization(self, data: Dict[str, Any], purpose: str) -> Dict[str, Any]:
        """
        Apply data minimization by removing unnecessary fields for the specified purpose.
        
        Args:
            data: Data to minimize
            purpose: Purpose for which the data will be used
            
        Returns:
            Minimized data
        """
        if not self.config["data_minimization_enabled"]:
            return data
        
        minimized = {}
        
        # Define comprehensive required fields for different purposes
        purpose_fields = {
            "authentication": [
                "user_id", "auth_token", "session_id", "mfa_status", "auth_method",
                "login_timestamp", "auth_provider", "security_level", "token_expiry"
            ],
            "personalization": [
                "preferences", "settings", "theme", "language", "timezone", "display_name",
                "notification_settings", "accessibility_settings", "ui_density", "favorite_features"
            ],
            "analytics": [
                "usage_stats", "feature_usage", "session_duration", "interaction_counts",
                "error_rates", "performance_metrics", "feature_engagement", "conversion_metrics",
                "retention_data", "platform_info", "app_version"
            ],
            "support": [
                "user_id", "issue_description", "system_info", "app_version", "logs",
                "error_messages", "steps_to_reproduce", "affected_features", "support_ticket_id",
                "priority_level", "impact_description"
            ],
            "billing": [
                "subscription_id", "plan_type", "billing_cycle", "payment_status",
                "subscription_features", "usage_limits", "renewal_date", "account_status"
            ],
            "communication": [
                "contact_info", "communication_preferences", "opt_in_status",
                "preferred_channel", "message_type", "frequency_settings"
            ],
            "research": [
                "anonymized_id", "demographic_category", "usage_patterns", "feature_preferences",
                "survey_responses", "feedback_category", "sentiment_data"
            ],
            "legal": [
                "terms_acceptance", "privacy_policy_version", "consent_records",
                "data_processing_agreements", "compliance_status"
            ]
        }
        
        # Define essential fields that should always be included regardless of purpose
        essential_fields = ["id", "metadata", "timestamp", "version"]
        
        # Define sensitive fields that should be excluded unless explicitly required
        sensitive_fields = {
            "high_sensitivity": [
                "password", "password_hash", "credit_card", "ssn", "health_data",
                "biometric_data", "precise_location", "private_messages"
            ],
            "medium_sensitivity": [
                "full_name", "email", "phone", "address", "date_of_birth",
                "ip_address", "device_identifiers", "browsing_history"
            ]
        }
        
        # Get required fields for the purpose
        required_fields = purpose_fields.get(purpose, [])
        
        # Add essential fields to required fields
        required_fields.extend(essential_fields)
        
        # Create a set for faster lookups
        required_fields_set = set(required_fields)
        
        # Process all fields in the data
        for field, value in data.items():
            # Include field if it's required for the purpose
            if field in required_fields_set:
                minimized[field] = value
                continue
                
            # Check if field is in any sensitive category
            is_sensitive = False
            for sensitivity, fields in sensitive_fields.items():
                if field in fields:
                    is_sensitive = True
                    break
                    
            # Skip sensitive fields not explicitly required
            if is_sensitive:
                continue
                
            # For nested objects, apply minimization recursively if appropriate
            if isinstance(value, dict) and len(value) > 0:
                # Check if any nested fields are required (using dot notation in required fields)
                has_required_nested = any(
                    req_field.startswith(f"{field}.") for req_field in required_fields_set
                )
                
                if has_required_nested:
                    # Extract just the nested required fields
                    nested_required = [
                        req_field.split(".", 1)[1] for req_field in required_fields_set
                        if req_field.startswith(f"{field}.") and "." in req_field
                    ]
                    
                    # Create a temporary purpose for the nested minimization
                    nested_purpose = f"{purpose}_nested_{field}"
                    
                    # Add the nested required fields to our purpose fields dictionary
                    purpose_fields[nested_purpose] = nested_required
                    
                    # Apply minimization recursively
                    minimized[field] = self.apply_data_minimization(value, nested_purpose)
            
            # For specific purposes, include certain field types even if not explicitly listed
            if purpose == "analytics" and field.endswith("_count"):
                minimized[field] = value
            elif purpose == "research" and field.startswith("anonymized_"):
                minimized[field] = value
        
        # Add metadata
        minimized["_minimized"] = True
        minimized["_minimization_purpose"] = purpose
        minimized["_minimization_timestamp"] = datetime.now().isoformat()
        minimized["_fields_retained"] = len(minimized)
        minimized["_fields_removed"] = len(data) - len(minimized)
        
        return minimized
    
    def calculate_retention_date(self, data_category: DataCategory, 
                               policy: RetentionPolicy, custom_days: Optional[int] = None) -> Optional[datetime]:
        """
        Calculate the retention date for data based on policy.
        
        Args:
            data_category: Category of the data
            policy: Retention policy to apply
            custom_days: Custom retention period in days, required if policy is CUSTOM
            
        Returns:
            Retention date, or None if data should be kept permanently
        """
        if policy == RetentionPolicy.CUSTOM:
            if custom_days is None:
                raise ValueError("Custom retention policy requires custom_days parameter")
            days = custom_days
        else:
            days = self.config["default_retention"].get(policy)
        
        if days < 0:  # Permanent retention
            return None
        
        return datetime.now() + timedelta(days=days)
    
    def should_retain_data(self, data: Dict[str, Any], retention_date: datetime) -> bool:
        """
        Check if data should be retained based on retention date.
        
        Args:
            data: Data to evaluate
            retention_date: Date until which data should be retained
            
        Returns:
            True if data should be retained
        """
        return datetime.now() <= retention_date
    
    def get_privacy_impact_assessment(self, data_categories: List[DataCategory], 
                                    actions: List[PrivacyAction]) -> Dict[str, Any]:
        """
        Generate a privacy impact assessment for the specified data categories and actions.
        
        Args:
            data_categories: Categories of data to assess
            actions: Actions to assess
            
        Returns:
            Privacy impact assessment results
        """
        assessment = {
            "timestamp": datetime.now().isoformat(),
            "overall_risk": "low",
            "categories": {},
            "recommendations": []
        }
        
        # Risk levels for different data categories
        category_risks = {
            DataCategory.SYSTEM: "low",
            DataCategory.DIAGNOSTIC: "low",
            DataCategory.USER_PROVIDED: "medium",
            DataCategory.GENERATED: "medium",
            DataCategory.BIOMETRIC: "high",
            DataCategory.HEALTH: "high",
            DataCategory.FINANCIAL: "high",
            DataCategory.LOCATION: "medium",
        }
        
        # Risk levels for different actions
        action_risks = {
            PrivacyAction.COLLECT: "medium",
            PrivacyAction.STORE: "medium",
            PrivacyAction.PROCESS: "medium",
            PrivacyAction.SHARE: "high",
            PrivacyAction.DELETE: "low",
            PrivacyAction.ANONYMIZE: "low",
            PrivacyAction.EXPORT: "high",
        }
        
        # Assess each data category
        highest_risk = "low"
        risk_levels = ["low", "medium", "high"]
        
        for category in data_categories:
            category_name = category.name if isinstance(category, DataCategory) else category
            category_risk = category_risks.get(category, "medium")
            
            assessment["categories"][category_name] = {
                "risk_level": category_risk,
                "actions": {}
            }
            
            # Assess each action for this category
            for action in actions:
                action_name = action.value if isinstance(action, PrivacyAction) else action
                action_risk = action_risks.get(action, "medium")
                
                # Determine combined risk
                combined_risk_index = max(
                    risk_levels.index(category_risk),
                    risk_levels.index(action_risk)
                )
                combined_risk = risk_levels[combined_risk_index]
                
                assessment["categories"][category_name]["actions"][action_name] = {
                    "risk_level": combined_risk,
                    "mitigations": self._get_mitigations(category, action)
                }
                
                # Update highest risk
                if risk_levels.index(combined_risk) > risk_levels.index(highest_risk):
                    highest_risk = combined_risk
        
        # Set overall risk
        assessment["overall_risk"] = highest_risk
        
        # Generate recommendations
        assessment["recommendations"] = self._generate_recommendations(data_categories, actions, highest_risk)
        
        return assessment
    
    def _get_mitigations(self, data_category: DataCategory, action: PrivacyAction) -> List[str]:
        """
        Get mitigation strategies for a specific data category and action.
        
        Args:
            data_category: Category of data
            action: Action to mitigate
            
        Returns:
            List of mitigation strategies
        """
        mitigations = []
        
        # Common mitigations
        mitigations.append("Obtain explicit user consent")
        mitigations.append("Apply data minimization")
        
        # Category-specific mitigations
        if data_category in [DataCategory.BIOMETRIC, DataCategory.HEALTH, DataCategory.FINANCIAL]:
            mitigations.append("Apply strong encryption")
            mitigations.append("Implement strict access controls")
            mitigations.append("Maintain detailed audit logs")
        
        # Action-specific mitigations
        if action == PrivacyAction.SHARE:
            mitigations.append("Use data sharing agreements")
            mitigations.append("Anonymize data before sharing")
        elif action == PrivacyAction.STORE:
            mitigations.append("Define clear retention periods")
            mitigations.append("Implement secure storage")
        
        return mitigations
    
    def _generate_recommendations(self, data_categories: List[DataCategory], 
                               actions: List[PrivacyAction], risk_level: str) -> List[str]:
        """
        Generate recommendations based on data categories, actions, and risk level.
        
        Args:
            data_categories: Categories of data
            actions: Actions to assess
            risk_level: Overall risk level
            
        Returns:
            List of recommendations
        """
        recommendations = []
        
        # Basic recommendations
        recommendations.append("Maintain up-to-date privacy policy")
        recommendations.append("Implement privacy by design principles")
        
        # Risk-level recommendations
        if risk_level == "high":
            recommendations.append("Conduct full Data Protection Impact Assessment")
            recommendations.append("Implement enhanced security measures")
            recommendations.append("Consider appointing a Data Protection Officer")
        elif risk_level == "medium":
            recommendations.append("Review data handling procedures")
            recommendations.append("Implement regular privacy audits")
        
        # Category-specific recommendations
        sensitive_categories = [DataCategory.BIOMETRIC, DataCategory.HEALTH, DataCategory.FINANCIAL]
        if any(category in sensitive_categories for category in data_categories):
            recommendations.append("Implement special handling for sensitive data")
            recommendations.append("Consider additional legal requirements for sensitive data")
        
        # Action-specific recommendations
        if PrivacyAction.SHARE in actions:
            recommendations.append("Review all data sharing arrangements")
            recommendations.append("Implement data sharing agreements")
        
        return recommendations
    
    def update_config(self, new_config: Dict[str, Any]) -> None:
        """
        Update the configuration.
        
        Args:
            new_config: New configuration options
        """
        self.config.update(new_config)
